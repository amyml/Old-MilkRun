using UnityEngine;
using System.Collections;

//@script RequireComponent(AudioSource) //for Javascript
//[RequireComponent (typeof (AudioSource))] //for C#
public class scriptHover : MonoBehaviour {

	public string levelToLoad;
	public AudioClip soundOnHover;
	public AudioClip soundOnClick;
	public bool isQuitButton  			= false;
	public bool isGuiText	 			= true;
	public int hoveringFontSizeIncr 	= 0;
	public int selectWaitTimeSecs		= 0;
	
	void OnMouseEnter(){
		audio.PlayOneShot(soundOnHover);
		
		if(isGuiText)
			guiText.fontSize += hoveringFontSizeIncr;
	}
	
	void OnMouseExit()
	{
		if(isGuiText)
			guiText.fontSize -= hoveringFontSizeIncr;
	}
	
	void OnMouseUp(){
		audio.PlayOneShot(soundOnClick);
		//yield return new WaitForSeconds(selectWaitTimeSecs);
		if(isQuitButton)
		{
			Application.Quit();
		}
		else if(levelToLoad != null)
		{
			Application.LoadLevel(levelToLoad);
		}
	}
	
}

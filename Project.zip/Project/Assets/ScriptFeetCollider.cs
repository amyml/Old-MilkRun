using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FarseerPhysics.Dynamics.Joints;
using FarseerPhysics.Collision.Shapes;
using FVector2 = Microsoft.Xna.Framework.FVector2;



public class ScriptFeetCollider : MonoBehaviour {
	
	
		
	// Use this for initialization
	void Start () {
				
		//lastContacts = new List<Contact>();
		//Shape myShape = GetComponent<FSBodyComponent>().GetShape();
		
		
	}
	
	// Update is called once per frame
	void Update () {

	}
	


}

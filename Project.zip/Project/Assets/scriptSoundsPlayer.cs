using UnityEngine;
using System.Collections;

public class scriptSoundsPlayer : MonoBehaviour {
	
	public const int GAMEOVER = 0;
	public const int PLAYERJUMP = 1;
	public const int PLAYERCOLLISION = 2;
	public const int PLAYERHURT = 3;
	public const int EGGDEATH = 4;
	public const int COIN = 5;
	public const int PLAYERDOUBLEJUMP = 6;
	public const int PLAYERWIN = 7;
	public const int PLAYERGRUNT = 8;
	public const int LEVELMUSIC = 9;
	public const int MENUSELECT = 10;
	public const int PLAYERYEAH = 11;
	
	private int numSounds = 12;
	
	private ArrayList sounds;
	
	public AudioSource gameover;
	public AudioSource playerjump;
	public AudioSource playercollision;
	public AudioSource playerhurt;
	public AudioSource eggdeath;
	public AudioSource coin;
	public AudioSource playerdoublejump;
	public AudioSource playerwin;
	public AudioSource playergrunt;
	public AudioSource levelmusic;
	public AudioSource menuselect;
	public AudioSource playeryeah;
	
	public bool fadeInMusic = false;
	
	// Use this for initialization
	void Start () {
		sounds = new ArrayList();
		sounds.Add(gameover); 			// 0
		sounds.Add(playerjump); 		// 1
		sounds.Add(playercollision); 	// 2
		sounds.Add(playerhurt); 		// 3
		sounds.Add(eggdeath); 			// 4
		sounds.Add(coin); 				// 5
		sounds.Add(playerdoublejump); 	// 6
		sounds.Add(playerwin); 			// 7
		sounds.Add(playergrunt); 			// 8
		sounds.Add(levelmusic); 			// 9
		sounds.Add(menuselect); 			// 10
		sounds.Add(playeryeah); 			// 11
		
		StartLevelMusic();
	}
	
	private void StartLevelMusic() {
		if(fadeInMusic) {
			float vol = ((AudioSource)sounds[LEVELMUSIC]).volume;
			FadeInSound(LEVELMUSIC, vol, 0.01f);
		}
		else {
			((AudioSource)sounds[LEVELMUSIC]).PlayDelayed(0.0f);
		}
	}

	public void PlaySound(int soundIndex) {
		((AudioSource)sounds[soundIndex]).Play();
	}
	
	public void PlaySoundWithDelay(int soundIndex, float delay) {
		((AudioSource)sounds[soundIndex]).PlayDelayed(delay);
	}
	
	public void FadeInSound(int soundIndex, float maxVolume, float duration) {
		//if(!((AudioSource)sounds[soundIndex]).isPlaying) {
			StartCoroutine (FadeIn(soundIndex, maxVolume, duration));
		//}
	}
	
	public void FadeOutSound(int soundIndex, float duration) {
		if(((AudioSource)sounds[soundIndex]).isPlaying) {
			StartCoroutine (FadeOut(soundIndex, duration));
		}
	}
	
	public void FadeSoundTo(int soundIndex, float minVolume, float duration) {
		if(((AudioSource)sounds[soundIndex]).isPlaying) {
			StartCoroutine (FadeOut(soundIndex, minVolume, duration));
		}
	}
	
	public void setVolumeTo(int soundIndex, float vol) {
		((AudioSource)sounds[soundIndex]).volume = vol;
	}
	
	private IEnumerator FadeOut(int soundIndex, float minVolume, float duration)
	{
		AudioSource sound = (AudioSource)sounds[soundIndex];
		float t = sound.volume;
	    while (t > minVolume) {
	        t -= Time.deltaTime;
	        sound.volume = t;
	        yield return new WaitForSeconds(duration);
	    }
		
		//sound.Stop();

		yield return new WaitForSeconds(0.0f);
	}
	
	private IEnumerator FadeOut(int soundIndex, float duration)
	{
		AudioSource sound = (AudioSource)sounds[soundIndex];
		float t = sound.volume;
	    while (t > 0.0) {
	        t -= Time.deltaTime;
	        sound.volume = t;
	        yield return new WaitForSeconds(duration);
	    }
		
		sound.Stop();

		yield return new WaitForSeconds(0.0f);
	}
	
	private IEnumerator FadeIn(int soundIndex, float maxVolume, float duration)
	{
		AudioSource sound = (AudioSource)sounds[soundIndex];
		
		float t = 0.0f;
		if(!((AudioSource)sounds[soundIndex]).isPlaying) {
			t = 0.0f;
			sound.Play();
		}
		else {
			t = sound.volume;
		}
		
	    while (t < maxVolume) {
	        t += Time.deltaTime;
	        sound.volume = t;
	        yield return new WaitForSeconds(duration);
	    }

		yield return new WaitForSeconds(0.0f);
	}
}

using UnityEngine;
using System.Collections;

public class scriptPowerUp : MonoBehaviour {
	
	public enum PowerUp
	{
		Chocolate,
		Strawberry,
		None
	}
	
	public bool IsActive;
	public PowerUp CurrPower;
	
	// Use this for initialization
	void Start () {
		IsActive = false;
		CurrPower = PowerUp.None;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	
	public bool hasPowerUp()
	{
		return IsActive;	
	}
	
	public void DeactivatePowerUp()
	{
		IsActive = false;
		CurrPower = PowerUp.None;
	}
	
	public PowerUp GetCurrPower()
	{
		return CurrPower;	
	}
	
	public void SetCurrPower(PowerUp newPower)
	{
		CurrPower = newPower;
		if(CurrPower == PowerUp.None)
		{
			IsActive = false;	
		}
			
	}
	
}

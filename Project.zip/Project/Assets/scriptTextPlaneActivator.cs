using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptTextPlaneActivator : MonoBehaviour {
	
	private Body body;
	public GameObject textPlane = null;
	private scriptTextAnimation scriptTextAnimation;
	
	private bool activated = false;

	// Use this for initialization
	void Start () {
	
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.OnCollision += OnCollisionEvent;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		if((string) fixtureB.Body.UserData == "Player") {
			if(textPlane != null && !activated)
			{
				activated = true;
				scriptTextAnimation = (scriptTextAnimation)(textPlane.GetComponent("scriptTextAnimation"));
				scriptTextAnimation.ActivateAnimation();
				GameObject.Destroy(this.gameObject);
			}
		}
		
		return false;
	}
}

using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;


public class scriptHaltMomentum : MonoBehaviour {
	
	private Body body;
	
	private scriptMaster scriptMaster;
	
	// Use this for initialization
	void Start () {
		
		//ScriptMaster!!
		scriptMaster = (scriptMaster)(GameObject.Find("Main Camera").GetComponent("scriptMaster"));		
		
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.OnCollision += OnCollisionEvent;
		body.IsSensor = true;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		if(fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<ScriptCharCollisions>() != null)
		{
			fixtureB.Body.LinearVelocity = new FVector2(0.0f, fixtureB.Body.LinearVelocity.Y);
		
			if(fixtureB.UserData == "player")
			{
				scriptMaster.DisableCharacterControl();	
			}
		}
		
		return true;
	}
}

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FarseerPhysics.Collision.Shapes;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptAchievementCollectible : MonoBehaviour {
	
	
	private Body body;
	private scriptStatTracker scriptStatTracker;
	private bool collected = false;
	
	public enum Achievement { Bow = 0, Picture = 1 }
	public Achievement type = Achievement.Bow;
	
	private scriptGlobalInformation scriptGlobalInformation;	
	private scriptSoundsPlayer scriptSoundsPlayer;

	void Start () {
		
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.IsSensor = true;
		body.OnCollision += OnCollisionEvent;
		scriptStatTracker = (scriptStatTracker)(GameObject.Find("prefabStatTracker").GetComponent("scriptStatTracker"));
		scriptSoundsPlayer = (scriptSoundsPlayer)(GameObject.Find("Sounds").GetComponent("scriptSoundsPlayer"));
		
		GameObject gi = GameObject.Find("GlobalInformation");
		scriptGlobalInformation = null;
		if(gi)
			scriptGlobalInformation = (scriptGlobalInformation)(gi.GetComponent("scriptGlobalInformation"));
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		//A = you
		//B = them
		if(fixtureB.Body.UserFSBodyComponent.gameObject.tag == "MrMilk")
		{	
			if(!collected)
			{
				scriptStatTracker.DecreaseSecretCount();
				collected = true;
				scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.PLAYERYEAH);  //------------------------------ACHIEVEMENT SOUND!!!
				
				if(scriptGlobalInformation) {
					if(type == Achievement.Bow)
						scriptGlobalInformation.bowAchievement = true;
					else if(type == Achievement.Picture)
						scriptGlobalInformation.pictureAchievement = true;
				}
			}
			GameObject.Destroy(this.gameObject);
		}
		
		
		return true;
	}
	
}

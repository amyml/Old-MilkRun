using UnityEngine;
using System.Collections;

public class scriptGuiCollectibles : MonoBehaviour {

    public Vector2 posCoin 		= new Vector2(20,10);
    public Vector2 sizeCoin 		= new Vector2(130, 78); //specifically scaled to fit texture
    public Texture2D collectibleImage = null;
	public string guiCoinString = "";
	
    public Vector2 posString		= new Vector2(250,10);
    public Vector2 sizeString 		= new Vector2(400, 50); 
	public GUISkin mySkin;
	
	private ScriptCharAnimation ScriptCharAnimation;
	private scriptStatTracker scriptStatTracker;	
	
	bool displaying = true;
	
	void Start() {
		ScriptCharAnimation = (ScriptCharAnimation)(gameObject.GetComponent("ScriptCharAnimation"));
		scriptStatTracker = (scriptStatTracker)(GameObject.Find("prefabStatTracker").GetComponent("scriptStatTracker"));
	}
	
    void OnGUI()
    {	
		if(displaying)
		{
			GUI.DrawTexture(new Rect(Screen.width-posCoin.x, posCoin.y, sizeCoin.x, sizeCoin.y), collectibleImage);
			
			GUI.skin = mySkin;
			GUI.color = Color.black;
			int numCollected = scriptStatTracker.GetCollectiblesCollected();
			guiCoinString = "x " + numCollected;
			GUI.Label(new Rect(Screen.width-posString.x,posString.y,sizeString.x,sizeString.y), guiCoinString);
		}
    }
     
    public void EndDisplay()
	{
		displaying = false;
	}
}

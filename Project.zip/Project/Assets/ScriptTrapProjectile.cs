using UnityEngine;
using System.Collections;

public class ScriptTrapProjectile : ScriptProjectile {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	
}

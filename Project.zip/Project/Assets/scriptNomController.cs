using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using FarseerPhysics.Dynamics;
using FarseerPhysics.Collision.Shapes;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptNomController : MonoBehaviour {
	//script Master!!
	private scriptMaster scriptMaster;
	//Physics World
	private World physicsWorld;
	
	private Body body;
	
	
	
	public Transform player;
	public float moveSpeedIdle 		= 10.0f;
	public float moveSpeedEscape 	= 20.0f;
	public float moveWaitTime 		= 0.0f;
	public List<Transform> waypoints;
	
	public float visionRangeX 		= 5.0f;
	public float visionRangeY 		= 1.0f;
	
	
	private float moveTimer;
	private int facingDir			= 2; //left is 1; right is 2
	
	private int currWaypointIndex 	= 0;
	private Transform currWaypoint;
	public float targetEpsilon 		= 0.1f;
	public bool escaping 			= false;
	
	public bool reachedEscape 		= false;
	
	void Start () {
		//ScriptMaster
		scriptMaster = (scriptMaster)(GameObject.Find("Main Camera").GetComponent("scriptMaster"));		
		//physicsWorld = FSWorldComponent.PhysicsWorld;
		
		//Setting the main body
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.Mass = 0.0f;
		//body.FixedRotation = true;
		
		if(waypoints.Count > 0)
		{
			currWaypoint = waypoints[currWaypointIndex];
		}
		moveTimer = moveWaitTime;
		
		reachedEscape = false;
	}
	
	// Update is called once per frame
	void Update () {
		if(!player)
		{
			return;
		}
		
		if(scriptMaster.IsCharacterControlEnabled())
		{
			NomMovement();
		}
	}
	
	void NomMovement() {
		
		//Check location of player in relation to Nom
		Vector2 playerVector = player.position - this.transform.position;
				
		if(Mathf.Abs(playerVector.x) <= visionRangeX && Mathf.Abs(playerVector.y) <= visionRangeY) //Can see player
		{
			currWaypointIndex = findEscapeWaypointIndex(playerVector); //Find the best waypoint away from player to escape to
			currWaypoint = waypoints[currWaypointIndex];
			escaping = true;
		}
		else
		{
			escaping = false;
		}
		
		//Move towards the current waypoint
		if(currWaypoint)
		{
			Vector2 targetVector = currWaypoint.position - this.transform.position;
			float distanceToTarget = targetVector.magnitude;
			Vector2 directionToTarget = targetVector / distanceToTarget;  //normalized vector to target
			float dir = directionToTarget.x;
			
			if(distanceToTarget <= targetEpsilon) //Close enough to target
			{
				if(!escaping)
				{
					//Get the next waypoint
					currWaypointIndex = ++currWaypointIndex % waypoints.Count;
					currWaypoint = waypoints[currWaypointIndex];
					
					//Get new distance vectors, etc.
					targetVector = currWaypoint.position - this.transform.position;
					distanceToTarget = targetVector.magnitude;
					directionToTarget = targetVector / distanceToTarget;  //normalized vector to target
					dir = directionToTarget.x;

				}
				else if(escaping && !reachedEscape)
				{
					reachedEscape = true;
				}
			}
			else
			{
				reachedEscape = false;
			}
			
			if(!reachedEscape)
				moveTowards(dir, distanceToTarget);
			
			if((escaping && !reachedEscape && !facingTarget(directionToTarget)) || (!escaping && !facingTarget(directionToTarget))) //turn towards the target/player
				turnDirection();
			
			if(escaping)			//Nom animation of fear
			{
				if(reachedEscape)
					GetComponent<scriptNomAnimation>().ExtendedNotice();
				else
					GetComponent<scriptNomAnimation>().Notice();
			}
			else
			{
				GetComponent<scriptNomAnimation>().Unnotice();
			}
			
		}
	}
	
	void moveTowards(float dir, float distance) {
		moveTimer -= Time.deltaTime;
		if(moveTimer <= 0)
		{
			if(escaping)
				body.ApplyForce(new FVector2(dir*moveSpeedEscape, 0));
			else
				body.ApplyForce(new FVector2(dir*moveSpeedIdle, 0));
			moveTimer = moveWaitTime;
		}
	}
	
	bool facingTarget(Vector2 directionToTarget) {
		float toTarget = directionToTarget.x; //negative means to its left, positive means to its right
		if(toTarget < 0 && facingDir == 1 || toTarget > 0 && facingDir == 2)
			return true;
		else 
			return false;
	}
	
	void turnDirection(){
		if(facingDir == 1)
			facingDir = 2;
		else
			facingDir = 1;
	}
	
	//Find the best escape route from player to any waypoint
	//Right now, if player is in the way of a waypoint, it is ignored. So if Nom is pushed away from waypoints, it defaults
	//	to returning towards its #0 waypoint.
	int findEscapeWaypointIndex(Vector2 playerVector)
	{
		int bestEscapeIndex = 0;
		float bestEscapeDistance = -1;
		for(int i = 0; i < waypoints.Count; i++)
		{
			Vector2 waypointVector = waypoints[i].position - this.transform.position;
			
			if(waypointVector.x / playerVector.x > 0) //same direction --> player in the way to the waypoint
			{
				continue;	
			}
			else
			{
				float distanceToWaypoint = waypointVector.magnitude;
				if(distanceToWaypoint >= bestEscapeDistance)
				{
					bestEscapeIndex = i;
					bestEscapeDistance = distanceToWaypoint;
				}
			}
		}
		return bestEscapeIndex;
	}
	
	public bool IsEscaping()
	{
		return escaping;	
	}
	
	public int GetDirection()
	{
		return facingDir;
	}
}

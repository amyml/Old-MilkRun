using UnityEngine;
using System.Collections;

public class ScriptCharAnimation : MonoBehaviour {
	
	
    // Animations MAIN
    private Renderer jumpRenderer;
    private OTAnimatingSprite jumpSprite;
    private Renderer runRenderer;
    private OTAnimatingSprite runSprite;
	private Renderer jumpRunRenderer;
    private OTAnimatingSprite jumpRunSprite;
	private Renderer deathRenderer;
    private OTAnimatingSprite deathSprite;
	private Renderer hitRenderer;
    private OTAnimatingSprite hitSprite;
	private Renderer winRenderer;
    private OTAnimatingSprite winSprite;
	private Renderer eatNCRenderer;
    private OTAnimatingSprite eatNCSprite;
	private Renderer idleRenderer;
    private OTAnimatingSprite idleSprite;
	private Renderer eatNSRenderer;
    private OTAnimatingSprite eatNSSprite;
	
	private Renderer runShootRenderer;
    private OTAnimatingSprite runShootSprite;
	private Renderer jumpShootRenderer;
    private OTAnimatingSprite jumpShootSprite;
	private Renderer jumprunShootRenderer;
    private OTAnimatingSprite jumprunShootSprite;
	
	//Animations STORED 1
	private Renderer storedJumpRenderer;
    private OTAnimatingSprite storedJumpSprite;
	private Renderer storedRunRenderer;
    private OTAnimatingSprite storedRunSprite;
	private Renderer storedJumpRunRenderer;
    private OTAnimatingSprite storedJumpRunSprite;
	private Renderer storedHitRenderer;
    private OTAnimatingSprite storedHitSprite;
	private Renderer storedWinRenderer;
    private OTAnimatingSprite storedWinSprite;
	//private Renderer storedEatNCRenderer;
    //private OTAnimatingSprite storedEatNCSprite;
	//private Renderer storedEatNSRenderer;
    //private OTAnimatingSprite storedEatNSSprite;
	private Renderer storedIdleRenderer;
    private OTAnimatingSprite storedIdleSprite;
	
	//Animations STORED 2
	private Renderer stored2JumpRenderer;
    private OTAnimatingSprite stored2JumpSprite;
	private Renderer stored2RunRenderer;
    private OTAnimatingSprite stored2RunSprite;
	private Renderer stored2JumpRunRenderer;
    private OTAnimatingSprite stored2JumpRunSprite;
	private Renderer stored2HitRenderer;
    private OTAnimatingSprite stored2HitSprite;
	private Renderer stored2WinRenderer;
    private OTAnimatingSprite stored2WinSprite;
	//private Renderer stored2EatNCRenderer;
    //private OTAnimatingSprite stored2EatNCSprite;
	//private Renderer storedEatNSRenderer;
    //private OTAnimatingSprite storedEatNSSprite;
	private Renderer stored2IdleRenderer;
    private OTAnimatingSprite stored2IdleSprite;
	
	//Directions
    private int currFacingDir = 2;
	private int lastFacingDir = 1;
	
	//Mobility
	private bool movable;
	
	private int LEFT = 1;
	//private int RIGHT = 2;
		
	//Scripts
	private scriptCharController charScript;
	private ScriptCharCollisions charCollision;
	private scriptHealth charHealth;
	
	//Health loss related
	private float oldHealth;
	private float curHealth;
	private bool busy;
	private bool powerUp;
	
	private Renderer hitBlock;
	
	//NomType
	private float nomType = 2f;
	//0f = chocolate
	//1f = strawberry
	//2f = normal

	
	// Use this for initialization
	void Start () {
		
		//hitBlock renderer
		hitBlock = GameObject.Find ("hitBlockOw").renderer;
		
		//Scripts
		charScript = gameObject.GetComponent<scriptCharController>();
		charCollision = gameObject.GetComponent<ScriptCharCollisions>();
		charHealth = gameObject.GetComponent<scriptHealth>();
		
    	//Alive and movable
		movable = true;		
		//Display for power-ups off
		powerUp = false;

		LoadTexture("");
		Store1Texture("C");
		Store2Texture("S");
		
		//Shooting Animations
		runShootRenderer = GameObject.Find("playerSRunS").renderer;
    	runShootSprite = GameObject.Find("playerSRunS").GetComponent<OTAnimatingSprite>();
		jumprunShootRenderer = GameObject.Find("playerSJumpRunS").renderer;
    	jumprunShootSprite = GameObject.Find("playerSJumpRunS").GetComponent<OTAnimatingSprite>();
		jumpShootRenderer = GameObject.Find("playerSJumpS").renderer;
    	jumpShootSprite = GameObject.Find("playerSJumpS").GetComponent<OTAnimatingSprite>();
		
		runShootRenderer.enabled = false;
		jumprunShootRenderer.enabled = false;
		jumpShootRenderer.enabled = false;
		
		//Health
		oldHealth = charHealth.GetCurrHealth();
		curHealth = charHealth.GetCurrHealth();
		busy = false;
		
		//hit block
		hitBlock.enabled = false;
	}
	
	// Update is called once per frame
	void Update () {
		
		//Health
		curHealth = charHealth.GetCurrHealth();
	
		//Directions
		currFacingDir = charScript.GetDirection();
		
		if(currFacingDir != lastFacingDir && movable)
		{
			
			if(charScript.GetDirection() == LEFT)
			{
				//facing left
				jumpSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
       		    runSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				jumpRunSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				deathSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				hitSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				winSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				eatNCSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				idleSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				
				runShootSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				jumprunShootSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				jumpShootSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				
				storedJumpSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
       		    storedRunSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				storedJumpRunSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				storedHitSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				storedWinSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				//storedEatNCSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				//storedEatNSSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				storedIdleSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				
				stored2JumpSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
       		    stored2RunSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				stored2JumpRunSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				stored2HitSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				stored2WinSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				//stored2EatNCSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				//stored2EatNSSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				stored2IdleSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
			}
			else
			{
				//facing right
				jumpSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
       		    runSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);	
				jumpRunSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				deathSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				hitSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				winSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				eatNCSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				idleSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				
				runShootSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				jumprunShootSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				jumpShootSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				
				storedJumpSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
       		    storedRunSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				storedJumpRunSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				storedHitSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				storedWinSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				//storedEatNCSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				//storedEatNSSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				storedIdleSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				
				stored2JumpSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
       		    stored2RunSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				stored2JumpRunSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				stored2HitSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				stored2WinSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				//stored2EatNCSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				//stored2EatNSSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				stored2IdleSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
			}
			
		}
		
		//Update direction
		lastFacingDir = currFacingDir;
		
		//Player death animation
		if (!charCollision.IsAlive())
		{	
			
			runRenderer.enabled = false;
			hitRenderer.enabled = false;
			jumpRenderer.enabled = false;
			jumpRunRenderer.enabled = false;
			winRenderer.enabled = false;
			eatNCRenderer.enabled = false;
			idleRenderer.enabled = false;
			deathRenderer.enabled = true;
			
			KillMovements();
			
			deathSprite.animation.fps = 4f;
			deathSprite.animation.duration = 1.5f;
				
			if(!deathSprite.isPlaying)
       	   		deathSprite.Play();
			
		}
		else if (charCollision.IsFinished())
		{
			
			//Player completed the level
			
			runRenderer.enabled = false;
			hitRenderer.enabled = false;
			jumpRenderer.enabled = false;
			jumpRunRenderer.enabled = false;
			eatNCRenderer.enabled = false;
			idleRenderer.enabled = false;
			winRenderer.enabled = true;
			deathRenderer.enabled = false;
			
			KillMovements();
			
			winSprite.animation.fps = 4f;
			winSprite.animation.duration = 1.5f;
				
			if(!winSprite.isPlaying)
       	   		winSprite.Play();
			
			
		}
		else if (curHealth < oldHealth)
		{
			
			//Hit by enemy
			
			jumpRenderer.enabled = false;
			runRenderer.enabled = false;
			deathRenderer.enabled = false;
			jumpRunRenderer.enabled = false;
			eatNCRenderer.enabled = false;
			idleRenderer.enabled = false;
			winRenderer.enabled = false;
			hitRenderer.enabled = true;
			
			hitBlock.enabled = true;
			
			hitSprite.animation.fps = 2f;
			hitSprite.animation.duration = 0.25f;
							
			if(!hitSprite.isPlaying)
				hitSprite.Play();
			
			StartCoroutine(Hit ());
			
		}
		else
		{
			if (!busy)
			{			
				if(charScript.IsMoving())
				{						
					if(charScript.Run())
					{
						
						//Sprinting (holding down shift)
						runRenderer.enabled = true;
						hitRenderer.enabled = false;
						deathRenderer.enabled = false;
						jumpRunRenderer.enabled = false;
						winRenderer.enabled = false;
						eatNCRenderer.enabled = false;
						idleRenderer.enabled = false;
						
						runSprite.animation.fps = 16f;
						runSprite.animation.duration = 0.25f;
						
						if(!runSprite.isPlaying)
		       	   			runSprite.Play();
						
					}
					else
					{
						
						//Running				
						runRenderer.enabled = true;
						deathRenderer.enabled = false;
						hitRenderer.enabled = false;
						jumpRunRenderer.enabled = false;
						winRenderer.enabled = false;
						eatNCRenderer.enabled = false;
						idleRenderer.enabled = false;
						
						runSprite.animation.fps = 8f;
						runSprite.animation.duration = 0.5f;
						
						if(!runSprite.isPlaying)
		      	   			runSprite.Play();
						
					}
					
				}
				
				if (charScript.IsGrounded())
				{			
					jumpRenderer.enabled = false;
					runRenderer.enabled = true;
					deathRenderer.enabled = false;
					jumpRunRenderer.enabled = false;
					eatNCRenderer.enabled = false;
					hitRenderer.enabled = false;
					winRenderer.enabled = false;
					
					if (charScript.IsIdle())
					{
						//Idle
						runRenderer.enabled = false;
						idleRenderer.enabled = true;
						
						idleSprite.animation.fps = 4f;
						idleSprite.animation.duration = 1.5f;
						
						if(!idleSprite.isPlaying)
		       	   			idleSprite.Play();
					}
					
				}
				else
				{
					
					if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.LeftArrow))
					{
						
						//Running and Jumping
						runRenderer.enabled = false;
						hitRenderer.enabled = false;
						deathRenderer.enabled = false;
						jumpRenderer.enabled = false;
						winRenderer.enabled = false;
						idleRenderer.enabled = false;
						eatNCRenderer.enabled = false;
						jumpRunRenderer.enabled = true;
						
						jumpRunSprite.animation.fps = 16f;
						jumpRunSprite.animation.duration = 0.5f;
						
						if(!jumpRunSprite.isPlaying)
		       	   			jumpRunSprite.Play();
						
					}
					else
					{
						
						//Vertical Jumping
						jumpRenderer.enabled = true;
						runRenderer.enabled = false;
						deathRenderer.enabled = false;
						hitRenderer.enabled = false;
						eatNCRenderer.enabled = false;
						jumpRunRenderer.enabled = false;
						idleRenderer.enabled = false;
						winRenderer.enabled = false;
						
						if(!jumpSprite.isPlaying)
							jumpSprite.Play();
						
					}				
				}
			}
		}
		
		//Health
		oldHealth = curHealth;
	}
	
	private void KillMovements()
	{
		//Kill all movements
		movable = false;
			
		//Kill all acceleration
		charScript.runSpeed = 0f;
		charScript.jumpInitialForce = 0f;
		charScript.walkSpeed = 0f;
		charScript.walkAirAcceleration = 0f;
		charScript.runAirAcceleration = 0f;
		charScript.runningJumpMultiplier = 0f;
		charScript.jumpHoldForce = 0f;	
	}
	
	private IEnumerator Hit()
	{
		busy = true;
		
		//Allow time for hit recoil
		yield return new WaitForSeconds(0.5f);
		
		hitRenderer.enabled = false;
		hitBlock.enabled = false;
		runRenderer.enabled = true;
		busy = false;
		
		if (GetComponent<scriptPowerUp>().GetCurrPower() == scriptPowerUp.PowerUp.None)
		{
			LoadTexture("");
			Store1Texture("C");
			Store2Texture("S");
			
			nomType = 2f;			
			powerUp = false;
		}
	}
	
	//Called by ScriptCharCollisions
	public void EatNC(float type)
	{		
		nomType = type;
			
		jumpRenderer.enabled = false;
		runRenderer.enabled = false;
		deathRenderer.enabled = false;
		jumpRunRenderer.enabled = false;
		winRenderer.enabled = false;
		hitRenderer.enabled = false;
		idleRenderer.enabled = false;
		
		if (nomType == 0f)
		{
			eatNSRenderer.enabled = false;
			eatNCRenderer.enabled = true;
			//Chocolate
			eatNCSprite.animation.fps = 8f;
			eatNCSprite.animation.duration = 0.5f;
							
			if(!eatNCSprite.isPlaying)
				eatNCSprite.Play();
		}
		else if (nomType == 1f)
		{
			eatNCRenderer.enabled = false;
			eatNSRenderer.enabled = true;
			//Strawberry
			eatNSSprite.animation.fps = 8f;
			eatNSSprite.animation.duration = 0.5f;
							
			if(!eatNSSprite.isPlaying)
				eatNSSprite.Play();
		}
			
		StartCoroutine(Eat ());
	}
	
	private IEnumerator Eat()
	{
		busy = true;
		
		//Wait for eating animation to play
		yield return new WaitForSeconds(0.75f);//1.25f
		
		eatNCRenderer.enabled = false;
		runRenderer.enabled = true;
		busy = false;
		
		//Display color of power up
		if (nomType == 0f)
		{
			//Chocolate
			LoadTexture("C");
			Store1Texture("");
			Store2Texture("S");
		}
		else if (nomType == 1f)
		{
			//Strawberry
			LoadTexture("S");
			Store1Texture("");
			Store2Texture("C");
		}
		powerUp = true;

	}
	
	//Called by scriptCharController
	public void Shoot()
	{
		int val = 0;
		if (runRenderer.enabled == true)
		{
			val = 1;
			runShootRenderer.enabled = true;
			runRenderer.enabled = false;
			
			runShootSprite.animation.fps = 16f;
			runShootSprite.animation.duration = 0.25f;
						
			if(!runShootSprite.isPlaying)
		    	runShootSprite.Play();
			
		}
		else if (jumpRenderer.enabled == true)
		{
			val = 2;
			jumpShootRenderer.enabled = true;
			jumpRenderer.enabled = false;
			
			if(!jumpShootSprite.isPlaying)
				jumpShootSprite.Play();
			
		}
		else if (jumpRunRenderer.enabled == true)
		{
			val = 3;
			jumprunShootRenderer.enabled = true;
			jumpRunRenderer.enabled = false;
			
			jumprunShootSprite.animation.fps = 16f;
			jumprunShootSprite.animation.duration = 0.5f;
						
			if(!jumprunShootSprite.isPlaying)
		    	jumprunShootSprite.Play();
			
		}
		else{
			val = 0;
			runShootRenderer.enabled = true;
			runRenderer.enabled = false;
			jumpRenderer.enabled = false;
			jumpRunRenderer.enabled = false;
			idleRenderer.enabled = false;
			hitRenderer.enabled = false;
		}
		
		StartCoroutine(WaitShoot(val));
	}
	
	private IEnumerator WaitShoot(int val)
	{
		busy = true;
		
		//Wait for eating animation to play
		yield return new WaitForSeconds(0.5f);
		
		if (val == 1 || val == 0)
		{
			runRenderer.enabled = true;
			runShootRenderer.enabled = false;
		}
		else if (val == 2)
		{
			jumpRenderer.enabled = true;
			jumpShootRenderer.enabled = false;
		}
		else if (val == 3)
		{
			jumpRunRenderer.enabled = true;
			jumprunShootRenderer.enabled = false;
		}
		
		busy = false;
	}
	
	//Load default milk
	private void LoadTexture(string s)
	{
		jumpRenderer = GameObject.Find("player" + s + "Jump").renderer;
    	jumpSprite = GameObject.Find("player" + s + "Jump").GetComponent<OTAnimatingSprite>();

    	runRenderer = GameObject.Find("player" + s + "Run").renderer;
    	runSprite = GameObject.Find("player" + s + "Run").GetComponent<OTAnimatingSprite>();
	
		jumpRunRenderer = GameObject.Find("player" + s + "JumpRun").renderer;
    	jumpRunSprite = GameObject.Find("player" + s + "JumpRun").GetComponent<OTAnimatingSprite>();
		
		if ( s != "C" && s != "S")
		{
			deathRenderer = GameObject.Find("player" + s + "Death").renderer;
    		deathSprite = GameObject.Find("player" + s + "Death").GetComponent<OTAnimatingSprite>();
			
			eatNCRenderer = GameObject.Find("player" + s + "EatNC").renderer;
    		eatNCSprite = GameObject.Find("player" + s + "EatNC").GetComponent<OTAnimatingSprite>();
			
			eatNSRenderer = GameObject.Find("player" + s + "EatNS").renderer;
    		eatNSSprite = GameObject.Find("player" + s + "EatNS").GetComponent<OTAnimatingSprite>();
		}

		hitRenderer = GameObject.Find("player" + s + "Hit").renderer;
    	hitSprite = GameObject.Find("player" + s + "Hit").GetComponent<OTAnimatingSprite>();

		winRenderer = GameObject.Find("player" + s + "Win").renderer;
    	winSprite = GameObject.Find("player" + s + "Win").GetComponent<OTAnimatingSprite>();

		idleRenderer = GameObject.Find("player" + s + "Idle").renderer;
    	idleSprite = GameObject.Find("player" + s + "Idle").GetComponent<OTAnimatingSprite>();		
		
		jumpRenderer.enabled = false;
    	runRenderer.enabled = true;	
    	jumpRunRenderer.enabled = false;
    	deathRenderer.enabled = false;	
    	hitRenderer.enabled = false;
    	winRenderer.enabled = false;
    	eatNCRenderer.enabled = false;
		eatNSRenderer.enabled = false;
    	idleRenderer.enabled = false;
	}
	
	//Store chocolate 
	private void Store1Texture(string s)
	{
		storedJumpRenderer = GameObject.Find("player" + s + "Jump").renderer;
    	storedJumpSprite = GameObject.Find("player" + s + "Jump").GetComponent<OTAnimatingSprite>();
		
		storedRunRenderer = GameObject.Find("player" + s + "Run").renderer;
    	storedRunSprite = GameObject.Find("player" + s + "Run").GetComponent<OTAnimatingSprite>();
		
		storedJumpRunRenderer = GameObject.Find("player" + s + "JumpRun").renderer;
    	storedJumpRunSprite = GameObject.Find("player" + s + "JumpRun").GetComponent<OTAnimatingSprite>();

		storedHitRenderer = GameObject.Find("player" + s + "Hit").renderer;
    	storedHitSprite = GameObject.Find("player" + s + "Hit").GetComponent<OTAnimatingSprite>();

		storedWinRenderer = GameObject.Find("player" + s + "Win").renderer;
    	storedWinSprite = GameObject.Find("player" + s + "Win").GetComponent<OTAnimatingSprite>();

		//storedEatNCRenderer = GameObject.Find("player" + s + "EatNC").renderer;
    	//storedEatNCSprite = GameObject.Find("player" + s + "EatNC").GetComponent<OTAnimatingSprite>();
		//storedEatNSRenderer = GameObject.Find("player" + s + "EatNS").renderer;
    	//storedEatNSSprite = GameObject.Find("player" + s + "EatNS").GetComponent<OTAnimatingSprite>();

		storedIdleRenderer = GameObject.Find("player" + s + "Idle").renderer;
    	storedIdleSprite = GameObject.Find("player" + s + "Idle").GetComponent<OTAnimatingSprite>();
		
		storedJumpRenderer.enabled = false;
		storedRunRenderer.enabled = false;
		storedJumpRunRenderer.enabled = false;	
    	storedHitRenderer.enabled = false;
    	storedWinRenderer.enabled = false;
    	//storedEatNCRenderer.enabled = false;
		//storedEatNSRenderer.enabled = false;
    	storedIdleRenderer.enabled = false;
	}
	
	//Store strawberry 
	private void Store2Texture(string s)
	{
		stored2JumpRenderer = GameObject.Find("player" + s + "Jump").renderer;
    	stored2JumpSprite = GameObject.Find("player" + s + "Jump").GetComponent<OTAnimatingSprite>();
		
		stored2RunRenderer = GameObject.Find("player" + s + "Run").renderer;
    	stored2RunSprite = GameObject.Find("player" + s + "Run").GetComponent<OTAnimatingSprite>();
		
		stored2JumpRunRenderer = GameObject.Find("player" + s + "JumpRun").renderer;
    	stored2JumpRunSprite = GameObject.Find("player" + s + "JumpRun").GetComponent<OTAnimatingSprite>();

		stored2HitRenderer = GameObject.Find("player" + s + "Hit").renderer;
    	stored2HitSprite = GameObject.Find("player" + s + "Hit").GetComponent<OTAnimatingSprite>();

		stored2WinRenderer = GameObject.Find("player" + s + "Win").renderer;
    	stored2WinSprite = GameObject.Find("player" + s + "Win").GetComponent<OTAnimatingSprite>();

		//stored2EatNCRenderer = GameObject.Find("player" + s + "EatNC").renderer;
    	//stored2EatNCSprite = GameObject.Find("player" + s + "EatNC").GetComponent<OTAnimatingSprite>();
		//stored2EatNSRenderer = GameObject.Find("player" + s + "EatNS").renderer;
    	//stored2EatNSSprite = GameObject.Find("player" + s + "EatNS").GetComponent<OTAnimatingSprite>();

		stored2IdleRenderer = GameObject.Find("player" + s + "Idle").renderer;
    	stored2IdleSprite = GameObject.Find("player" + s + "Idle").GetComponent<OTAnimatingSprite>();
		
		stored2JumpRenderer.enabled = false;
		stored2RunRenderer.enabled = false;
		stored2JumpRunRenderer.enabled = false;	
    	stored2HitRenderer.enabled = false;
    	stored2WinRenderer.enabled = false;
    	//stored2EatNCRenderer.enabled = false;
		//stored2EatNSRenderer.enabled = false;
    	stored2IdleRenderer.enabled = false;
	}
	
	public bool GetPowerStatus()
	{
		return powerUp;	
	}
	
	public float GetPowerType(){
		return nomType;
	}
	
}

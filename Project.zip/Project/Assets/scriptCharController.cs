using UnityEngine;
using System.Collections.Generic;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

using FJoint = FarseerPhysics.Dynamics.Joints;

public class scriptCharController : MonoBehaviour
{
	//script Master!!
	private scriptMaster scriptMaster;
	
	private ScriptCharCollisions scriptCollisions;
	
	private Body body;
	private bool run = false;
	//private float defaultFriction;	
	
	//Hidden Jump variables (basically flagging when the character can jump
	//private bool grounded = true; NOW IN SCRIPTCOLLISIONS!!
	private bool jumpState = false;
	private float jumpTimer = 0.0f;
	private int facingDir = 2; //left is 1; right is 2

	
	//public variables for designers
	public float walkSpeed = 10.0f;
	public float walkAirAcceleration = 10.0f;
	
	public float runSpeed = 20.0f;
	public float runSpeedMax = 30.0f;
	public float runRampUpTime = 1.0f;
	public float runAirAcceleration = 10.0f;
	
	public float jumpInitialForce = 700.0f;
	public float jumpHoldForce = 100.0f;
	public float jumpHoldTime = 1.0f; //in seconds
	public float runningJumpMultiplier = 1.0f;
	public float minHorzontalSpeedForMaxJump = 15.0f;
	public float gravityScale = 1.0f;
	
	
	public scriptPowerUp PowerUpScript;
	private int ExtraJumps = 0;
	public int MaxExtraJumps = 1;
	
	private FSRevoluteJointComponent wheel;
	
	private ScriptProjectileWeapon scriptWeapon;
	
	private scriptSoundsPlayer scriptSoundsPlayer;
	
	void Start()
	{
		//ScriptMaster!!
		scriptMaster = (scriptMaster)(GameObject.Find("Main Camera").GetComponent("scriptMaster"));		
		// scriptBackground = (scriptBackgroundMovement)(GameObject.Find("Main Camera").GetComponent("scriptBackgroundMovement"));	
		scriptCollisions = GetComponent<ScriptCharCollisions>();
		scriptSoundsPlayer = (scriptSoundsPlayer)(GameObject.Find("Sounds").GetComponent("scriptSoundsPlayer"));
		
		PowerUpScript = GetComponent<scriptPowerUp>();
		
		//Setting the main body
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.Mass = 0.0f;
		body.Restitution = -1.0f;
		body.FixedRotation = true;
		body.IsBullet = true;
		body.GravityScale = gravityScale;
		
		wheel = gameObject.GetComponent<FSRevoluteJointComponent>();
		
		scriptWeapon = gameObject.GetComponent<ScriptProjectileWeapon>();
						
	}

	void Update()
	{	
		
		//PowerUp checks
		scriptPowerUp.PowerUp PowerUpType = PowerUpScript.GetCurrPower();		
		
		if(scriptMaster.IsCharacterControlEnabled())
		{
			HorizontalInput();
			JumpInput();
			
			if( PowerUpType == scriptPowerUp.PowerUp.Strawberry )
			{
				WeaponInput();
			}
		}
		else 
		{
			wheel.SetMotorSpeed(0.0f);	
		}
		
		

		
		if( PowerUpType ==  scriptPowerUp.PowerUp.Chocolate && IsGrounded())
		{
			if(IsGrounded())
				ExtraJumps = MaxExtraJumps;	
		}
		else if(PowerUpType == scriptPowerUp.PowerUp.None)
		{
			ExtraJumps = 0;	
		}
		
	}
	
	private void WeaponInput()
	{
		if(Input.GetKeyDown(KeyCode.Z))
		{
			if(scriptWeapon != null)
			{
				scriptWeapon.FireShot();
				//shoot animation
				GetComponent<ScriptCharAnimation>().Shoot();
			}
		}
		
	}
	
	public void accelerate()
	{
		if(Mathf.Abs(wheel.MotorSpeed) >= runSpeedMax * 2.0f)
		{
			if(wheel.MotorSpeed < 0 )
				wheel.SetMotorSpeed(-runSpeedMax * 2.0f);
			else
				wheel.SetMotorSpeed(runSpeedMax * 2.0f);
		}
		
		float extraSpeed = (runSpeedMax - runSpeed) / runRampUpTime * Time.deltaTime * 2.0f;
		

		if(wheel.MotorSpeed < 0)
		{
			wheel.SetMotorSpeed(wheel.MotorSpeed - extraSpeed);
		}
		else
		{
			wheel.SetMotorSpeed(wheel.MotorSpeed + extraSpeed);
		}
		
	}
	
	public void SetGrounded(bool g)
	{
		scriptCollisions.SetGrounded(g);	
	}
	
	public bool IsGrounded()
	{
		return scriptCollisions.IsGrounded();	
	}
	
	public bool Run()
	{
		return run;	
	}
	
	//Can be true when the character is midair
	public bool IsMoving()
	{
		return body.LinearVelocity.Length() >= 0.001;	
	}
	
	//Requires no velocity and touching the ground
	public bool IsIdle()
	{
		return !IsMoving() && IsGrounded();	
	}
	
	public int GetDirection()
	{
		return facingDir;
	}
	
	
	private void HorizontalInput() 
	{
		if(Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift)) 
		{
			run = true;
		}
		else
		{
			run = false;
		}
			
		if(Input.GetKey(KeyCode.LeftArrow)) 
		{
            //Facing left
            facingDir = 1;
			if(run) 
			{
				if(wheel.MotorSpeed < runSpeed*2)
					wheel.SetMotorSpeed(runSpeed*2);
				else if(scriptCollisions.IsGrounded())
					accelerate();
			}
			else
			{
				wheel.SetMotorSpeed(walkSpeed*2);
			}
			
			if(!scriptCollisions.IsGrounded()) 
			{

				if(run)
				{
					body.ApplyForce(new FVector2(-runAirAcceleration*Time.deltaTime*60.0f,0));
				}
				else
				{
					body.ApplyForce(new FVector2(-walkAirAcceleration*Time.deltaTime*60.0f,0));	
				}
			}
		} 
		if(Input.GetKeyUp(KeyCode.LeftArrow) || Input.GetKeyUp(KeyCode.RightArrow))
		{
			wheel.SetMotorSpeed(0.0f);
		}
		if(Input.GetKey(KeyCode.RightArrow)) 
		{
            //Facing right
            facingDir = 2;

			if(run) 
			{
				if(wheel.MotorSpeed > -runSpeed*2)
					wheel.SetMotorSpeed(-runSpeed*2);
				else if(scriptCollisions.IsGrounded())
					accelerate();	
			}
			else
			{
				wheel.SetMotorSpeed(-walkSpeed*2);
			}
			
			if(!scriptCollisions.IsGrounded()) 
			{
				if(run)
				{
					body.ApplyForce(new FVector2(runAirAcceleration*Time.deltaTime*60.0f,0));
				}
				else
				{
					body.ApplyForce(new FVector2(walkAirAcceleration*Time.deltaTime*60.0f,0));	
				}
			}

		} 
		
	}
	
	private void JumpInput() 
	{

		if((Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow)) && (scriptCollisions.IsGrounded() || ExtraJumps > 0)) 
		{
			if(!IsGrounded()) //double jump
			{
				ExtraJumps--;
				body.LinearVelocity = new FVector2(body.LinearVelocity.X, 0.0f);
				
				scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.PLAYERDOUBLEJUMP);
			}
			else
			{
				scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.PLAYERJUMP);
			}
			

			if(run) 
			{
				float multiplier = runningJumpMultiplier*Mathf.Min(body.LinearVelocity.X/minHorzontalSpeedForMaxJump, 1.0f);
				body.ApplyForce(new FVector2(0.0f, Mathf.Max(multiplier*jumpInitialForce, jumpInitialForce)));
            }
			else
			{
				body.ApplyForce(new FVector2(0.0f, jumpInitialForce));
			}
			scriptCollisions.SetGrounded(false);
			jumpState = true;
			jumpTimer = jumpHoldTime;
			
			//Jump sound
		}
		
		if((Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.UpArrow)) && jumpState) 
		{
			jumpTimer -= Time.deltaTime;
			if(jumpTimer <= 0.0f)
			{
				jumpState = false;
			} 
			else 
			{
                body.ApplyForce(new FVector2(0.0f, jumpHoldForce*Time.deltaTime*60.0f));
			}
		}
		
		if(Input.GetKeyUp(KeyCode.Space) && Input.GetKeyUp(KeyCode.UpArrow))
		{
			jumpState = false;	
		}
		
	}
	
}
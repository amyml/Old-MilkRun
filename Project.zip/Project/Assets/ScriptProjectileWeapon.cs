using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class ScriptProjectileWeapon : MonoBehaviour {

	public GameObject projectile;
	public GameObject weaponHolder;
	
	public float xVelocity = 10.0f;
	public float yVelocity = 0.0f;
	
	public bool affectedByPlayerXMomemtum = true;
	public bool affectedByPlayerYMomemtum = false;
	
	public float cooldownTime = 0.2f;
	
	private float coolTimer = 9999.0f;
	private bool coolActive = false;
	
	private Body ownerBody;
	private int team;
	private int currentFacingDirection = 1;
	
	
	private scriptEggController scriptEgg;
	private scriptCharController scriptChar;
	
	
	
	// Use this for initialization
	void Start () {
		
		if( projectile == null || projectile.GetComponent<ScriptProjectile>() == null)
		{
				
		}
		
		if( weaponHolder == null || weaponHolder.GetComponent<FSBodyComponent>() == null)
		{
			weaponHolder = gameObject;
			ownerBody = weaponHolder.GetComponent<FSBodyComponent>().PhysicsBody;
			
			if(ownerBody == null)
			{
					
			}
		}
		else
		{
			ownerBody = weaponHolder.GetComponent<FSBodyComponent>().PhysicsBody;	
		}
		
		
		scriptHealth holderHealth = weaponHolder.GetComponent<scriptHealth>();
		if(holderHealth != null)
		{
			team = holderHealth.GetTeam();	
		}
		else
		{
			team = 0;	
		}
		
		scriptChar = gameObject.GetComponent<scriptCharController>();
		
		if(scriptChar == null)
		{
			scriptEgg = gameObject.GetComponent<scriptEggController>();	
			if(scriptEgg == null)
			{
				
			}
		}
		
	}
	
	// Update is called once per frame
	void Update () {
		UpdateDirection();
		TickCoolDown();
		//FireShot();
	}
	
	
	public void FireShot()
	{
		if(!coolActive)
		{
			GameObject firedObject = (GameObject) GameObject.Instantiate(projectile, gameObject.transform.position, gameObject.transform.rotation);
			
			//Set the velocity
			float xVel = currentFacingDirection*xVelocity;
			float yVel = yVelocity;
				
			if(affectedByPlayerXMomemtum){
				xVel += ownerBody.LinearVelocity.X;	
			}
			if(affectedByPlayerYMomemtum){
				yVelocity += ownerBody.LinearVelocity.Y;	
			}
			
			
			Body firedBody = firedObject.GetComponent<FSBodyComponent>().PhysicsBody;
			firedBody.LinearVelocity = new FVector2(xVel, yVel);
			
			ScriptProjectile scriptProj = firedObject.GetComponent<ScriptProjectile>();
			
			scriptProj.SetTeam(team);
			
			ActivateCoolDown();
		}
			
	}
	
	private void UpdateDirection()
	{
		if(scriptChar != null)
		{
			if(scriptChar.GetDirection() == 1)	
				currentFacingDirection = -1;
			else
				currentFacingDirection = 1;
		}
		else if(scriptEgg != null)
		{
			if(scriptEgg.GetDirection() == 1)	
				currentFacingDirection = -1;
			else
				currentFacingDirection = 1;
		}
	}
	
	private void ActivateCoolDown()
	{
		coolActive = true;
		coolTimer = cooldownTime;
	}
	
	private void TickCoolDown()
	{
		if(coolActive)
		{
			coolTimer -= Time.deltaTime;
			if(coolTimer <= 0.0f )
			{
				coolActive = false;	
			}
		}
	}
}

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FarseerPhysics.Collision.Shapes;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptNomCollisions : MonoBehaviour {
	
	private Body body;
	private scriptStatTracker scriptStatTracker;
	private bool eaten = false;
	
	private FVector2 startPosition;
	public float respawnTime = 3.0f;
	private float respawnTimer = 999.0f;
	

	void Start () {
		
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		
		body.FixedRotation = true;
		
		startPosition = new FVector2(body.Position.X, body.Position.Y);
		
		body.OnCollision += OnCollisionEvent;
		scriptStatTracker = (scriptStatTracker)(GameObject.Find("prefabStatTracker").GetComponent("scriptStatTracker"));
	}
	
	
	void Update()
	{
		if(eaten)
		{
			TickRespawnTimer();
			//print ("timer " + respawnTimer );
			if(respawnTimer <= 0.0f)
			{
				eaten = false;
				UnVanish();	
			}
		}
		
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		if(!eaten)
		{
			//If Mr. Milk touches Nom, Nom gets eaten		
			ScriptCharCollisions player = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<ScriptCharCollisions>();
			scriptPowerUp playerPowerScript = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptPowerUp>();
			
			//print ("not eaten");
			
			if (player != null && fixtureA.Body.UserFSBodyComponent.gameObject.tag == "ChocolateNom")
			{
				eaten = true;
				playerPowerScript.SetCurrPower(scriptPowerUp.PowerUp.Chocolate);
				//Cue player animation to eat nom
				player.EatNC(0f);
				scriptStatTracker.DecreaseNomCount();
				//StartCoroutine(Die ());
				Vanish ();
			}
			else if (player != null && fixtureA.Body.UserFSBodyComponent.gameObject.tag == "StrawberryNom")
			{
				eaten = true;
				playerPowerScript.SetCurrPower(scriptPowerUp.PowerUp.Strawberry);
				//Cue player animation to eat nom
				player.EatNC(1f);
				scriptStatTracker.DecreaseNomCount();
				//StartCoroutine(Die ());
				Vanish ();
			}
		}
		
		
		if(fixtureB.Body.IsStatic)
		{
			return true;
		}
		else
		{
			return false;	
		}		
	}
	
	// Function handles the nom's death
	private IEnumerator Die()
	{
		
		//Wait for death animation to play out
		yield return new WaitForSeconds(0.25f);

		//Destroy the nom
		Destroy(gameObject);
		
	}
	
	
	private void Vanish()
	{
		//body.IsSensor = true;
		gameObject.transform.position = new Vector3(1000.0f, 1000.0f, -999.0f);
		
		respawnTimer = respawnTime;
		
	}
	
	private void UnVanish()
	{
		body.Position = new FVector2(startPosition.X, startPosition.Y);
		gameObject.transform.position = new Vector3(startPosition.X, startPosition.Y, 0.0f);
		body.LinearVelocity = new FVector2(0.0f,0.0f);
		body.IgnoreGravity = false;
		eaten = false;
	}
	
	private void TickRespawnTimer()
	{
		respawnTimer -= Time.deltaTime;	
	}
	
}

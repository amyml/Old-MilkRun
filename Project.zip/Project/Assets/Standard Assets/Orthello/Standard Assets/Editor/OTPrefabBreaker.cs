#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using System.Collections;
// DEPRECATED
public class OTPrefabBreaker : Editor
{		
}
#endif
using UnityEngine;
using System.Collections;
// DEPRECATED
[ExecuteInEditMode]
public class OTPB : MonoBehaviour {		
}
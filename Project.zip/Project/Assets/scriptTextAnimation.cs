using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptTextAnimation : MonoBehaviour {
	public bool activateOnStart = false;
	
	public enum IntroAnimation { Fade = 0, FlyDown = 1, FlyRight = 2, FlyLeft = 3, FlyUp = 4 }
	public enum OutroAnimation { Fade = 0, FlyDown = 1, FlyRight = 2, FlyLeft = 3, FlyUp = 4, None = 5 }
	public IntroAnimation introAnimation = IntroAnimation.Fade;
	public OutroAnimation outroAnimation = OutroAnimation.Fade;
	
	//public float introDuration = 1.0f;
	public float holdDuration = 2.0f;
	//public float outroDuration = 1.0f;
	
	private float introSpeedPercent = 0.0f;
	public float introSpeedMovement = 0.3f;
	private float outroSpeedPercent = 0.0f;
	public float outroSpeedMovement = 0.3f;
	
	public bool followsPlayerVertically = true;
	public bool followsPlayerHorizontally = true;
	public bool followsPlayerOnExit = false;
	
	public float distFromPlayerY = 1.0f;
	public float distFromPlayerX = -0.5f;
	
	private GameObject player;
	private bool animatingX = true;
	private bool animatingY = true;
	
	private float upY = 12.0f;
	private float downY = -12.0f;
	private float leftX = -15.0f;
	private float rightX = 15.0f;
	
	private bool exiting = false;
	
	// Use this for initialization
	void Start () {
		effectTimer = effectLength;
		
		Vector3 pos = this.transform.position;
		pos.z = 5;
		this.transform.position = pos;
		player = GameObject.FindGameObjectWithTag("MrMilk");
		
		renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, 0.0f);
		if(introAnimation == IntroAnimation.Fade)
		{
			renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, 0.0f);
		}
		else if(introAnimation == IntroAnimation.FlyDown)
		{
			Vector3 currPos = this.transform.position;
			currPos.y = upY;
			this.transform.position = currPos;
		}
		else if(introAnimation == IntroAnimation.FlyUp)
		{
			Vector3 currPos = this.transform.position;
			currPos.y = downY;
			this.transform.position = currPos;
		}
		/*
		else if(introAnimation == IntroAnimation.FlyRight)
		{
			Vector3 currPos = this.transform.position;
			currPos.x = player.transform.position.x + leftX;
			this.transform.position = currPos;
		}
		else //FlyLeft
		{
			Vector3 currPos = this.transform.position;
			currPos.x = player.transform.position.x + rightX;
			this.transform.position = currPos;
		}
		*/
		
		if(activateOnStart)
			ActivateAnimation();
	}
	
	void FixedUpdate () {
		if(exiting && !followsPlayerOnExit)
			return;
		if(followsPlayerVertically || followsPlayerHorizontally) {
			Vector3 pos = player.transform.position;
			pos.z = 5;
			
			if(!animatingY && followsPlayerVertically)
				pos.y = pos.y + distFromPlayerY;
			else
				pos.y = this.transform.position.y;
			
			if(!animatingX && followsPlayerHorizontally)
				pos.x = pos.x + distFromPlayerX;
			else
				pos.x = this.transform.position.x;
			
			this.transform.position = pos;
		}
	}
	
	
	public enum Effect { None = 0, Pulsing = 1, Blinking = 2 }
	public Effect effect = Effect.None;
	private bool addingMoreEffect = true;
	public float effectLength = 1.0f;
	public float effectSpeed = 2.0f;
	private float effectTimer = 1.0f;
	void Update() {
		float time = Time.deltaTime;
		effectTimer -= time;
		
		if(effect == Effect.Pulsing)
		{
			if(addingMoreEffect)
			{
				this.transform.localScale += new Vector3(time, time, time) * effectSpeed;
			}
			else
			{
				this.transform.localScale -= new Vector3(time, time, time) * effectSpeed;
			}
		}
		
		if(effect == Effect.Blinking)
		{
			if(addingMoreEffect)
			{
				renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, 1.0f);
			}
			else
			{
				renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, 0.0f);
			}
		}
		
			
		
		if(effectTimer <= 0.0f)
		{
			effectTimer = effectLength;
			addingMoreEffect = !addingMoreEffect;
		}
	}

	
	public void ActivateAnimation() {
		StartCoroutine ("Intro");
	}
	
	IEnumerator Intro() 
	{
		if(introAnimation == IntroAnimation.Fade)
		{
			animatingY = false;
			animatingX = false;
			float alpha = 0.0f;
			while (alpha < 1.0f) {
				alpha += introSpeedMovement;
				renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, alpha);
				yield return new WaitForSeconds(introSpeedPercent);
			}
		}
		else{
			renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, 1.0f);
			if(introAnimation == IntroAnimation.FlyDown)
			{
				animatingY = true;
				animatingX = false;
				float newY = upY;
				while (newY > player.transform.position.y + distFromPlayerY) {
					newY -= introSpeedMovement;
					
					Vector3 pos = this.transform.position;
					pos.y = newY;
					this.transform.position = pos;
					yield return new WaitForSeconds(introSpeedPercent);
				}
				//distFromPlayerY = this.transform.position.y - player.transform.position.y;
			}
			else if(introAnimation == IntroAnimation.FlyRight)
			{
				animatingY = false;
				animatingX = true;
				float newX = player.transform.position.x + leftX;
				while (newX < player.transform.position.x + distFromPlayerX) {
					newX += introSpeedMovement;
					
					Vector3 pos = this.transform.position;
					pos.x = newX;
					this.transform.position = pos;
					yield return new WaitForSeconds(introSpeedPercent);
				}
				//distFromPlayerX = this.transform.position.x - player.transform.position.x;
			}
			else if(introAnimation == IntroAnimation.FlyLeft)
			{
				animatingY = false;
				animatingX = true;
				float newX = player.transform.position.x + rightX;
				while (newX > player.transform.position.x + distFromPlayerX) {
					newX -= introSpeedMovement;
					
					Vector3 pos = this.transform.position;
					pos.x = newX;
					this.transform.position = pos;
					yield return new WaitForSeconds(introSpeedPercent);
				}
				//distFromPlayerX = this.transform.position.x - player.transform.position.x;
			}
			else // introAnimation == IntroAnimation.FlyUp
			{
				animatingY = true;
				animatingX = false;
				float newY = downY;
				while (newY < player.transform.position.y + distFromPlayerY) {
					newY += introSpeedMovement;
					
					Vector3 pos = this.transform.position;
					pos.y = newY;
					this.transform.position = pos;
					yield return new WaitForSeconds(introSpeedPercent);
				}
				//distFromPlayerY = this.transform.position.y - player.transform.position.y;
			}
		}
		
		
		animatingY = false;
		animatingX = false;
		StartCoroutine("Hold");
		yield return null;
    }
	
	IEnumerator Hold() 
	{
		yield return new WaitForSeconds(holdDuration);
		StartCoroutine("Outro");
		yield return null;
    }
	
	IEnumerator Outro() 
	{
		exiting = true;
		if(outroAnimation == OutroAnimation.Fade)
		{
			animatingY = false;
			animatingX = false;
			float alpha = 1.0f;
			while (alpha > 0.0f) {
				alpha -= 0.05f;
				renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, alpha);
				yield return new WaitForSeconds(outroSpeedPercent);
			}
		}
		else{
			renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, 1.0f);
			if(outroAnimation == OutroAnimation.FlyDown)
			{
				animatingY = true;
				animatingX = false;
				float newY = this.transform.position.y;
				while (newY > downY) {
					newY -= 0.10f;
					
					Vector3 pos = this.transform.position;
					pos.y = newY;
					this.transform.position = pos;
					yield return new WaitForSeconds(outroSpeedPercent);
				}
				//distFromPlayerY = this.transform.position.y - player.transform.position.y;
			}
			else if(outroAnimation == OutroAnimation.FlyRight)
			{
				animatingY = false;
				animatingX = true;
				float newX = this.transform.position.x;
				while (newX < player.transform.position.x + rightX) {
					newX += 0.15f;
					
					Vector3 pos = this.transform.position;
					pos.x = newX;
					this.transform.position = pos;
					yield return new WaitForSeconds(outroSpeedPercent);
				}
				//distFromPlayerX = this.transform.position.x - player.transform.position.x;
			}
			else if(outroAnimation == OutroAnimation.FlyLeft)
			{
				animatingY = false;
				animatingX = true;
				float newX = this.transform.position.x;
				while (newX > player.transform.position.x + leftX) {
					newX -= 0.15f;
					
					Vector3 pos = this.transform.position;
					pos.x = newX;
					this.transform.position = pos;
					yield return new WaitForSeconds(outroSpeedPercent);
				}
				//distFromPlayerX = this.transform.position.x - player.transform.position.x;
			}
			else if(outroAnimation == OutroAnimation.FlyUp)
			{
				animatingY = true;
				animatingX = false;
				float newY = this.transform.position.y;
				while (newY < upY) {
					newY += 0.10f;
					
					Vector3 pos = this.transform.position;
					pos.y = newY;
					this.transform.position = pos;
					yield return new WaitForSeconds(outroSpeedPercent);
				}
			}
			/*
			else // NONE
			{
				//Do nothing
			}
			*/
		}
		
		animatingY = false;
		animatingX = false;
		
		if(outroAnimation != OutroAnimation.None) {
			renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, 0.0f);
		}
			
		yield return null;
    }
}

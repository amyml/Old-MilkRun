#pragma strict

var color : Color;
function Start () {
	this.renderer.material.color = Color(0.8,0.1,0.1); //171,8,8
}

function Update () {

}
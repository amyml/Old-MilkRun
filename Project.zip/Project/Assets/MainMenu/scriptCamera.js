#pragma strict

function Start () {
this.camera.orthographicSize = 5.3f;
}

function Update () {
this.camera.orthographicSize = 5.3f;
}
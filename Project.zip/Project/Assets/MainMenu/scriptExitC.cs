using UnityEngine;
using System.Collections;

public class scriptExitC : MonoBehaviour {
	
	private Renderer exitRenderer;

	// Use this for initialization
	void Start () {
		exitRenderer = GameObject.Find("bigExit").renderer;
		exitRenderer.enabled = false;
	}
	
	void OnMouseEnter() {
		exitRenderer.enabled = true;
		renderer.enabled = false;
	}
	
	void OnMouseExit() {
		renderer.enabled = true;
		exitRenderer.enabled = false;
	}
	
	void OnMouseDown(){
    	Application.Quit();
	}
}

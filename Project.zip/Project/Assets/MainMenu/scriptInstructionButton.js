#pragma strict

function OnMouseDown(){
    Application.LoadLevel("Instructions");
}
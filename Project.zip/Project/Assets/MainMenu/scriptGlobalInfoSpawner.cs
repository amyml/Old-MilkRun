using UnityEngine;
using System.Collections;

public class scriptGlobalInfoSpawner : MonoBehaviour {
	
	public GameObject globalInformationObj;

	// Use this for initialization
	void Start () {
		if(GameObject.Find("GlobalInformation") == null)
		{
			GameObject info = (GameObject)GameObject.Instantiate(globalInformationObj);
			info.name = "GlobalInformation";
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

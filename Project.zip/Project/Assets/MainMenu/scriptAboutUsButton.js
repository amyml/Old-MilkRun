#pragma strict

function OnMouseDown(){
    Application.LoadLevel("AboutUs");
}
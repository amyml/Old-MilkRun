using UnityEngine;
using System.Collections;

public class scriptQuestion : MonoBehaviour {
	
	// Animations MAIN
    private Renderer selectRenderer;
    private OTAnimatingSprite selectSprite;
	
	private bool hover = false;

	// Use this for initialization
	void Start () {
		selectRenderer = GameObject.Find("MenuEggQuestion").renderer;
    	selectSprite = GameObject.Find("MenuEggQuestion").GetComponent<OTAnimatingSprite>();
		selectRenderer.enabled = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (hover){
			if (!selectSprite.isPlaying)
				selectSprite.Play ();
		}
	}
	
	void OnMouseEnter() {
		hover = true;
		selectRenderer.enabled = true;
		renderer.enabled = false;
	}
	
	void OnMouseExit() {
		hover = false;
		selectRenderer.enabled = false;
		renderer.enabled = true;
	}
	
	void OnMouseDown(){
    	Application.LoadLevel("AboutUs");
	}
}
	

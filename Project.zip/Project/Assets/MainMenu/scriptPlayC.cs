using UnityEngine;
using System.Collections;

public class scriptPlayC : MonoBehaviour {

	private Renderer playRenderer;

	// Use this for initialization
	void Start () {
		playRenderer = GameObject.Find("bigPlay").renderer;
		playRenderer.enabled = false;
	}
	
	void OnMouseEnter() {
		playRenderer.enabled = true;
		renderer.enabled = false;
	}
	
	void OnMouseExit() {
		renderer.enabled = true;
		playRenderer.enabled = false;
	}
	
	void OnMouseDown(){
    	Application.LoadLevel("sceneLevelSelect");
	}
}

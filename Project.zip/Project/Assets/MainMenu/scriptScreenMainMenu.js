#pragma strict

//Player Script

//Inspector Variables
var buttonSize : float = 50.0;


//Private Variables


//Update is called every frame
function Update () {

}

function OnGUI()
{
	if(GUI.Button(Rect(10,10,buttonSize,50), "Start Game"))
	{
		Application.LoadLevel("sceneLevel1");
	}
	if(GUI.Button(Rect(10,70,buttonSize,50), "Exit Game"))
	{
		Application.Quit();
	}

}

function Start () {

}
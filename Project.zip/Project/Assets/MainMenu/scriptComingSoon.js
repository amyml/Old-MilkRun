#pragma strict

var text : GUIText;

function Start () {
	text.enabled = false;
}

function OnMouseOver()
{
	text.enabled = true;
}

function OnMouseExit()
{
	text.enabled = false;
}
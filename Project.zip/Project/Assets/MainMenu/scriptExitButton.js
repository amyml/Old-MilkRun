#pragma strict

function OnMouseDown(){
    Application.Quit();
}
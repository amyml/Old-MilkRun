using UnityEngine;
using System.Collections;

public class scriptSecretCavePlane : MonoBehaviour {
	
	private GameObject player;
	public float newAlpha = 0.8f;
	public float distToDisappear = 3.3f;

	// Use this for initialization
	void Start () {
		player = GameObject.FindGameObjectWithTag("MrMilk");
	}
	
	// Update is called once per frame
	void Update () {
		Vector2 targetVector = player.transform.position - this.transform.position;
		float distanceToPlayer = targetVector.magnitude;
		
		if(distanceToPlayer <= distToDisappear)
			renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, newAlpha);
		else
			renderer.material.color = new Color(renderer.material.color.r, renderer.material.color.g, renderer.material.color.b, 1.0f);
	}
}

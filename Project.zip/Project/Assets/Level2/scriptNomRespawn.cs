using UnityEngine;
using System.Collections;

public class scriptNomRespawn : MonoBehaviour {
	
	public GameObject prefabNom;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		GameObject nom = GameObject.FindGameObjectWithTag("StrawberryNom");
		
		if (nom == null)
		{
			StartCoroutine( RespawnWait() );
			
			Respawn();
		}
	
	}
	
	private IEnumerator RespawnWait()
	{
		
		//Allow time for animation
		yield return new WaitForSeconds(2f);

	}
	
	private void Respawn()
	{
		Instantiate(prefabNom); //Instantiate( prefabNom, new Vector3(49.9817f,6.106838f,0f), Quaternion.identity);
	}
}

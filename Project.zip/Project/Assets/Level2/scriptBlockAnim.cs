using UnityEngine;
using System.Collections;

public class scriptBlockAnim : MonoBehaviour {
	
	// Animations
    private Renderer breakRenderer;
    private OTAnimatingSprite breakSprite;
	
	private Component[] sprites;
	
	//Scripts
	private scriptHealth health;
	
	private float curHealth = 200f;

	// Use this for initialization
	void Start () {
		health = gameObject.GetComponent<scriptHealth>();
		
		//Sprites & Rendering Sprites
		sprites = GetComponentsInChildren<OTAnimatingSprite>();
		
		foreach (OTAnimatingSprite s in sprites){
			if(s.tag == "RockBreak")
				breakSprite = s;
		}
		
		breakRenderer = breakSprite.renderer;
		breakRenderer.enabled = true;
	}
	
	// Update is called once per frame
	void Update () {
		if (curHealth > 0f && curHealth != health.GetCurrHealth())
		{
			curHealth = health.GetCurrHealth();
			
			if (curHealth <= 0f)
			{
				if(!breakSprite.isPlaying){
	       	   		breakSprite.Play();
				}
				
				StartCoroutine(WaitBreak ());
			}
		}
	}
	
	private IEnumerator WaitBreak()
	{

		//Allow time for hanimation
		yield return new WaitForSeconds(1f);
		breakRenderer.enabled = false;

	}
}

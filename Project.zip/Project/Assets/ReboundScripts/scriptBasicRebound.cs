using UnityEngine;
using System.Collections;

public class scriptBasicRebound : ReboundProperty {

	public float Damage = 5.0f;
	public float XForce = 5.0f;
	public float YForce = 5.0f;
	public float MinVel = 15.0f;
	public float ImmobileTime = 0.5f;
	

	
	void Start ()
	{
		BaseDamage = Damage;
		BaseXForce = XForce;
		BaseYForce = YForce;
		BaseMinVel = MinVel;
		BaseImmobileTime = ImmobileTime;
	}
}

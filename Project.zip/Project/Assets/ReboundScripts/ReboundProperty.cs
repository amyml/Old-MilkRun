using UnityEngine;
using System.Collections;
using FVector2 = Microsoft.Xna.Framework.FVector2;


public class ReboundProperty : MonoBehaviour {

	
	protected float BaseDamage = 0.0f;
	protected float BaseXForce = 0.0f;
	protected float BaseYForce = 0.0f;
	protected float BaseMinVel = 9999.0f;
	protected float BaseImmobileTime = 0.0f;
	
	public float GetDamage()
	{
		return BaseDamage;	
	}
	
	public float GetDamage(float vel)
	{
		return BaseDamage;	
	}
	
	public float GetXForce()
	{
		return BaseXForce;	
	}
	
	public float GetYForce()
	{
		return BaseYForce;	
	}
	
	public FVector2 GetForce()
	{
		return new FVector2(BaseXForce, BaseYForce);	
	}
	
	public float GetMinVelocity()
	{
		return BaseMinVel;	
	}
	
	public float GetImmobileTime()
	{
		return BaseImmobileTime;	
	}
		
	
}

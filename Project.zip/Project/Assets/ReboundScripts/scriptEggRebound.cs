using UnityEngine;
using System.Collections;

public class scriptEggRebound : ReboundProperty {

	public float Damage = 0.0f;
	public float XForce = 5.0f;
	public float YForce = 5.0f;
	public float MinVel = 0.0f;
	public float ImmobileTime = 0.1f;
	

	
	void Start ()
	{
		BaseDamage = Damage;
		BaseXForce = XForce;
		BaseYForce = YForce;
		BaseMinVel = MinVel;
		BaseImmobileTime = ImmobileTime;
	}
}
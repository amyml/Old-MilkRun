using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FarseerPhysics.Collision.Shapes;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class ScriptCharCollisions : MonoBehaviour {
	
	
	public  float noFricLandingMaxTime = 0.01f;
	private float noFricLandingTime = 0.0f;
	private bool landingTimerSet = false;
	private float defaultFriction;
	
	private float deathDuration = 5.0f;	
		
	private Body body;
	
	//ScriptMaster!!
	private scriptMaster scriptMaster;
	
	//Main body
	private Fixture mainBody;
	private bool alive;
	private bool finishLevel;
	
	//FeetCollider info
	private Fixture feetCollider;
	private List<Contact> groundContacts;
	private bool grounded;	
	private bool wasGrounded;
	
	//HeadCollider info
	private Fixture headCollider;
	private List<Contact> headContacts;
	private bool headTouching;

	//LeftSideCollider info
	private Fixture leftCollider;
	private List<Contact> leftContacts;
	//private bool isLeftTouching;	
	
	//RightSideCollider info
	private Fixture rightCollider;
	private List<Contact> rightContacts;
	private bool isRightTouching;	
	
	private FSRevoluteJointComponent wheel;

	private scriptSoundsPlayer scriptSoundsPlayer;
	
	// Use this for initialization
	void Start () {
		
		//ScriptMaster!!
		scriptMaster = (scriptMaster)(GameObject.Find("Main Camera").GetComponent("scriptMaster"));	
		scriptSoundsPlayer = (scriptSoundsPlayer)(GameObject.Find("Sounds").GetComponent("scriptSoundsPlayer"));
	
		wheel = gameObject.GetComponent<FSRevoluteJointComponent>();
		//bodyB is the actual wheel, bodyA is the square mainbody collider.
		wheel.BodyB.PhysicsBody.OnCollision += OnWheelCollisionEvent;
		wheel.CollideConnected = false;
		
		wheel.BodyB.PhysicsBody.IsSensor = true;
		
		
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.OnCollision += OnCollisionEvent;	
		
		body.UserData = "Player";
		
		alive = true;
		finishLevel = false;		
		
		wasGrounded = grounded;
		
		
		//Fixture 0 is the main body
		mainBody = body.FixtureList[0];
		defaultFriction = mainBody.Friction;		
		
		
		//Fixture 1 is the feet collider!!
		feetCollider = body.FixtureList[1];
		feetCollider.IsSensor = true;
		groundContacts = new List<Contact>();
		
		

		
		//Fixture 2 is the head collider!!
		headCollider = body.FixtureList[2];
		headCollider.IsSensor = true;
		headContacts = new List<Contact>();
		
		//Fixture 3 is the left side collider!!
		leftCollider = body.FixtureList[3];
		leftCollider.Friction = 0.0f;
		leftCollider.IsSensor = true;
		leftContacts = new List<Contact>();
		//isLeftTouching = false;		
		
		//Fixture 4 is the right side collider!!
		rightCollider = body.FixtureList[4];
		rightCollider.Friction = 0.0f;
		leftCollider.IsSensor = true;
		rightContacts = new List<Contact>();
		isRightTouching = false;
		
		wheel.BodyB.PhysicsBody.IsSensor = false;

	}
	
	// Update is called once per frame
	void Update () {
		
			
			//print (wheel.LocalAnchorB);
		
			float test = FVector2.Distance(wheel.BodyB.PhysicsBody.Position,wheel.BodyA.PhysicsBody.Position);
		
		/*	if(test > 0.5f)
			{
				wheel.BodyA.PhysicsBody.IsSensor = true;
				print ("AAAAAAAAHHHHH!!!");
			}*/
		
			//Update Contact Flags!!!
			CheckGroundContacts();
			CheckHeadContacts();
			CheckLeftContacts();
			CheckRightContacts();
		
			wasGrounded = grounded;
		
			if(landingTimerSet)
			{
				noFricLandingTime -= Time.deltaTime;
				if(noFricLandingTime <= 0.0f)
				{

					landingTimerSet = false;
					mainBody.Friction = defaultFriction;
				}
			}

			if (finishLevel)
			{
				Win();
			}
		
			if(GetComponent<scriptHealth>().Dead() && alive) //turn dead
			{
				alive = false;
				Death();
			}
	}
	
	public void Finish()
	{
		finishLevel = true;
	}
	
	public bool IsFinished()
	{
		return finishLevel;
	}
	
	public bool IsAlive()
	{
		return alive;	
	}
	
	public bool IsGrounded()
	{
		return 	grounded;
	}
	
	public void SetGrounded(bool g)
	{
		grounded = g;	
	}
	
	public bool IsHeadTouching()
	{
		return headTouching;	
	}
	
	public bool IsRightTouching()
	{
		return isRightTouching;	
	}
	
	public FVector2 GetVelocity()
	{
		return body.LinearVelocity;	
	}
	
	private void CheckGroundContacts()
	{
		//Check if the character is grounded
		if(groundContacts.Count < 1)
		{
			
		} 
		else
		{
			foreach(Contact groundContact in groundContacts)
			{
				bool isTouching = groundContact.IsTouching();
				if(isTouching) {
					grounded = true;
					break;	
				}
				grounded = false;
			}
			for(int i = 0; i < groundContacts.Count; i++)
			{
				if(!groundContacts[i].IsTouching())
				{
					groundContacts.RemoveAt(i);
					i = Mathf.Max(0, i - 1);
				}
			}
		}	
	}	

	private void CheckLeftContacts()
	{
		//Check if the character is grounded
		if(groundContacts.Count < 1)
		{
			
		} 
		else
		{
			/*foreach(Contact leftContact in leftContacts)
			{
				bool isTouching = leftContact.IsTouching();
				if(isTouching) {
					isLeftTouching = true;
					break;	
				}
				isLeftTouching = false;
			}*/
			for(int i = 0; i < leftContacts.Count; i++)
			{
				if(!leftContacts[i].IsTouching())
				{
					leftContacts.RemoveAt(i);
					i = Mathf.Max(0, i - 1);
				}
			}
		}	
	}	
	
	private void CheckRightContacts()
	{
		//Check if the character is grounded
		if(groundContacts.Count < 1)
		{
			
		} 
		else
		{
			foreach(Contact rightContact in rightContacts)
			{
				bool isTouching = rightContact.IsTouching();
				if(isTouching) {
					isRightTouching = true;
					break;	
				}
				isRightTouching = false;
			}
			for(int i = 0; i < rightContacts.Count; i++)
			{
				if(!rightContacts[i].IsTouching())
				{
					rightContacts.RemoveAt(i);
					i = Mathf.Max(0, i - 1);
				}
			}
		}	
	}
	
	private void CheckHeadContacts()
	{
		//Check if the character is banging his head on something
		if(headContacts.Count < 1)
		{
			headTouching = false; 
		} 
		else
		{
			foreach(Contact headContact in headContacts)
			{
				bool isTouching = headContact.IsTouching();
				if(isTouching) {
					headTouching = true;
					break;	
				}
				headTouching = false;
			}
			for(int i = 0; i < headContacts.Count; i++)
			{
				if(!headContacts[i].IsTouching())
				{
					headContacts.RemoveAt(i);
					i = Mathf.Max(0, i - 1);
				}
			}
		}	
	}
	
	private bool OnWheelCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		scriptHealth health = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptHealth>();
		
		if(health != null)
		{
			if(health.Dead() == true)
			{
					return false;
			}
		}
		
		return true;
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		scriptHealth health = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptHealth>();
		
		if(health != null)
		{
			if(health.Dead() == true)
			{
					return false;
			}
		}
		
		
		if(fixtureA == feetCollider) 
		{
			//grounded = true;
			if(!groundContacts.Contains(contact))
				groundContacts.Add(contact);
			
			if(!wasGrounded)
			{
				SetNoFrictionTimer();
			}
		}
		
		if(fixtureA == headCollider)
		{
			if(!headContacts.Contains(contact))
				headContacts.Add(contact);
		}
		
		if(fixtureA == leftCollider && !fixtureB.IsSensor)
		{
			if(!leftContacts.Contains(contact))
				leftContacts.Add(contact);
			
			ReboundProperty ReboundInfo = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<ReboundProperty>();
			
			if(ReboundInfo != null)
			{
				if(body.LinearVelocity.X <= -ReboundInfo.GetMinVelocity())
				{
					Rebound (ReboundInfo);
				}
			}
			return false;
		}			
		
		if(fixtureA == rightCollider && !fixtureB.IsSensor)
		{
			if(!rightContacts.Contains(contact))
				rightContacts.Add(contact);
			
			ReboundProperty ReboundInfo = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<ReboundProperty>();

			if(ReboundInfo != null)
			{
				if(body.LinearVelocity.X >= ReboundInfo.GetMinVelocity())
				{
					Rebound(-ReboundInfo.GetXForce(), ReboundInfo.GetYForce(), ReboundInfo.GetDamage(), ReboundInfo.GetImmobileTime() );
					
				}
			}
			return false;
			
		}
		
	
		
		if(fixtureA != feetCollider && (string) fixtureB.Body.UserData == "Enemy")
		{
			
		}
		
		if(fixtureA == feetCollider && (string) fixtureB.Body.UserData == "Enemy")
		{
				
		}
		
	

		return true;
	}
	
	public void Rebound(float HorizontalForce, float VerticalForce, float ImpactDamage, float ImmobileTime)
	{
		//Disable control, stops the player and rebounds him back
		GetComponent<scriptHealth>().Damage(ImpactDamage);
		scriptMaster.DisableCharacterControl(ImmobileTime);
		body.LinearVelocity = new FVector2(0.0f, 0.0f);
		body.ApplyLinearImpulse(new FVector2(HorizontalForce,VerticalForce), new FVector2(0,0));
		
		scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.PLAYERCOLLISION);
		scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.PLAYERGRUNT);
	}
	
	public void Rebound(ReboundProperty ReboundInfo)
	{
		if(ReboundInfo != null)
		{
			Rebound (ReboundInfo.GetXForce(), ReboundInfo.GetYForce(), ReboundInfo.GetDamage(), ReboundInfo.GetImmobileTime());
		}
		
	}
	
	public void SetNoFrictionTimer()
	{
		mainBody.Friction = 0.0f;
		landingTimerSet = true;
		noFricLandingTime = noFricLandingMaxTime;
	}
	
	
	public void EatNC(float type)
	{
		GetComponent<ScriptCharAnimation>().EatNC(type);
		
		scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.EGGDEATH);
	}
	
	public void Death()
	{
		StartCoroutine (Die ());
	}
	
	public void Win()
	{
		StartCoroutine (LevelEnd ());
	}
	
	// Function handles the character death
	// Makes the screen go black and reloads the current level
	private IEnumerator Die()
	{
		scriptSoundsPlayer.FadeOutSound(scriptSoundsPlayer.LEVELMUSIC, 0.03f);
		scriptSoundsPlayer.PlaySoundWithDelay(scriptSoundsPlayer.GAMEOVER, 0.5f);
		yield return new WaitForSeconds(1.5f);
		
		Destroy (gameObject);
		
		// Create a GUITexture for black screen effect
  		GameObject fade = new GameObject();
  		fade.AddComponent("GUITexture");
  		// Set to screen dimensions
		fade.guiTexture.pixelInset= new Rect(0, 0, Screen.width, Screen.height);
  		// Set its texture to a black pixel
  		Texture2D tex = new Texture2D(1, 1);
  		tex.SetPixel(0, 0, Color.black);
  		tex.Apply();
  		fade.guiTexture.texture = tex;
  		// Fade it during duration seconds
		// Note: the fade currently is abrupt, need more research on timing
  		for (float alpha = 0.0f; alpha < 1.0f; ){
    		alpha += Time.deltaTime / deathDuration;
			fade.guiTexture.color = new Color(fade.guiTexture.color.r, fade.guiTexture.color.g, fade.guiTexture.color.b, alpha);	
		}
		// Reload the current level:
  		Application.LoadLevel(Application.loadedLevel);		
	}

	// Function handles the character completing the level
	// Makes the screen go pink and loads the score screen
	private IEnumerator LevelEnd()
	{
		yield return new WaitForSeconds(14.0f);
		
		//Application.LoadLevel("Level2");	
		
		// Destroy (gameObject);
		
  		//Application.LoadLevel(Application.loadedLevel);
		// Application.LoadLevel("Level2");	
	}
	
}

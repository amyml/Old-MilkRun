using UnityEngine;
using System.Collections;

public class scriptMaster : MonoBehaviour {
	
	public bool debugMode = false;
	
	private bool charControlEnabled = true;
	
	private float disableCharacterControlTimer;
	private bool disableCharacterControlTimerSet = false;
	
	
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	
		if(disableCharacterControlTimerSet)
		{
			disableCharacterControlTimer -= Time.deltaTime;	
			if(disableCharacterControlTimer <= 0.0f)
			{
				charControlEnabled = true;
				disableCharacterControlTimerSet = false;
			}
		}
	}
	
	public bool DebugMode()
	{
		return debugMode;	
	}
	
	public void DisableCharacterControl(float t)
	{
		charControlEnabled = false;
		disableCharacterControlTimer = t;
		disableCharacterControlTimerSet = true;
	}
	
	public void DisableCharacterControl()
	{
		charControlEnabled = false;
		disableCharacterControlTimerSet = false;
	}
	
	public void EnableCharacterControl()
	{
		if(disableCharacterControlTimer > 0.0f)
		{
			charControlEnabled = false;
			disableCharacterControlTimerSet = true;
		}
		else
		{
			charControlEnabled = true;
		}
	}
	
	public bool IsCharacterControlEnabled()
	{
		return charControlEnabled;	
	}
}

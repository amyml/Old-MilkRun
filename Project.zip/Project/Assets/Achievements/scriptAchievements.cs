using UnityEngine;
using System.Collections;

public class scriptAchievements : MonoBehaviour {
	
	private scriptGlobalInformation scriptGlobalInformation;	
	
	public Texture2D achievementTitle = null;
	public Texture2D backArrow = null;
    public Texture2D bowAchievementEmpty = null;
	public Texture2D bowAchievement = null;
	public Texture2D pictureAchievementEmpty = null;
	public Texture2D pictureAchievement = null;
	public Texture2D chocolateNom = null;
	public Texture2D strawberryNom = null;
	public Texture2D coin = null;	
	public Texture2D egg = null;
	
	public GUISkin mySkin;

	// Use this for initialization
	void Start () {
		scriptGlobalInformation = (scriptGlobalInformation)(GameObject.Find("GlobalInformation").GetComponent("scriptGlobalInformation"));

		//GUI.skin = mySkin;
		//GUI.color = Color.white;
		
		string coinWord = scriptGlobalInformation.totalCoinsCollected == 1 ? " Coin " : " Coins ";
		string totalCoinsString = scriptGlobalInformation.totalCoinsCollected + " total" + coinWord + "collected";
		
		string nomWord = scriptGlobalInformation.totalNomsEaten == 1 ? " Nom " : " Noms ";
		string totalNomsString = scriptGlobalInformation.totalNomsEaten + " total" + nomWord + "eaten";
		
		string enemyWord = scriptGlobalInformation.totalEnemiesDefeated == 1 ? " Egg " : " Eggs ";
		string totalEnemiesString = scriptGlobalInformation.totalEnemiesDefeated + " total" + enemyWord + "defeated";
		TextMesh coinsText = (TextMesh)GameObject.Find("totalCoinsString").gameObject.GetComponent<TextMesh>();
		coinsText.text = totalCoinsString;
		TextMesh nomsText = (TextMesh)GameObject.Find("totalNomsString").gameObject.GetComponent<TextMesh>();
		nomsText.text = totalNomsString;
		TextMesh enemiesText = (TextMesh)GameObject.Find("totalEnemiesString").gameObject.GetComponent<TextMesh>();
		enemiesText.text = totalEnemiesString;
		
		if(scriptGlobalInformation.bowAchievement) {
			GameObject.Find("bowAchievement").gameObject.renderer.enabled = true;
			GameObject.Find("bowAchievementEmpty").gameObject.renderer.enabled = false;
		}
		else {
			GameObject.Find("bowAchievement").gameObject.renderer.enabled = false;
			GameObject.Find("bowAchievementEmpty").gameObject.renderer.enabled = true;
		}
		
		if(scriptGlobalInformation.pictureAchievement) {
			GameObject.Find("pictureAchievement").gameObject.renderer.enabled = true;
			GameObject.Find("pictureAchievementEmpty").gameObject.renderer.enabled = false;
		}
		else {
			GameObject.Find("pictureAchievement").gameObject.renderer.enabled = false;
			GameObject.Find("pictureAchievementEmpty").gameObject.renderer.enabled = true;
		}
		//GameObject.Find("totalNomsString").GetComponent(TextMesh).text = totalNomsString;
		//GameObject.Find("totalEnemiesString").GetComponent(TextMesh).text = totalEnemiesString;
	}
	
	// Update is called once per frame
	void Update () {
		/*
		float achievementTitleWidth = 600.0f;
		GUI.DrawTexture(new Rect(Screen.width/2 - achievementTitleWidth/2, 20, achievementTitleWidth, 80), achievementTitle);
		
		Rect r = new Rect(10, 30, backArrow.width/7, backArrow.height/7);
		GUI.DrawTexture(r, backArrow);
		
		if(Input.GetMouseButton(0))
		{
		    if (r.Contains(Event.current.mousePosition)) {
				Application.LoadLevel("sceneMainMenu");
			}
		}
		
		if(scriptGlobalInformation.bowAchievement) {
			GUI.DrawTexture(new Rect(Screen.width/4, 150, 200, 100), bowAchievement);
		}
		else { //no bow achievement
			GUI.DrawTexture(new Rect(Screen.width/4, 150, 200, 100), bowAchievementEmpty);
		}
		
		if(scriptGlobalInformation.pictureAchievement) {
			GUI.DrawTexture(new Rect(Screen.width/2 +50, 130, 120, 120), pictureAchievement);
		}
		else { 
			GUI.DrawTexture(new Rect(Screen.width/2 +50, 130, 120, 120), pictureAchievementEmpty);
		}
		
		GUI.DrawTexture(new Rect(Screen.width/4, 270, 80, 80), coin);
		
		GUI.DrawTexture(new Rect(Screen.width/4 -15, 370, 60, 60), chocolateNom);
		GUI.DrawTexture(new Rect(Screen.width/4 +20, 360, 60, 70), strawberryNom);
		
		GUI.DrawTexture(new Rect(Screen.width/4, 450, 70, 80), egg);
		*/
		
		/*
		//Titles
		GUI.skin = mySkin;
		GUI.color = Color.white;
		
		string totalCoinsString = scriptGlobalInformation.totalCoinsCollected + " total Coins collected";
		string totalNomsString = scriptGlobalInformation.totalNomsEaten + " total Noms eaten";
		string totalEnemiesString = scriptGlobalInformation.totalEnemiesDefeated + " total Eggs defeated";
		GUI.Label(new Rect(Screen.width/4 +130, 280, 600, 200), totalCoinsString);
		GUI.Label(new Rect(Screen.width/4 +strawberryNom.width, 370, 600, 70), totalNomsString);
		GUI.Label(new Rect(Screen.width/4 +egg.width, 460, 600, 80), totalEnemiesString);
		*/
		/*
		GUI.skin = mySkin;
		GUI.color = Color.white;
		
		string totalCoinsString = scriptGlobalInformation.totalCoinsCollected + " total Coins collected";
		string totalNomsString = scriptGlobalInformation.totalNomsEaten + " total Noms eaten";
		string totalEnemiesString = scriptGlobalInformation.totalEnemiesDefeated + " total Eggs defeated";
		GameObject.Find("totalCoinsString").guiText = totalCoinsString;
		GameObject.Find("totalNomsString").guiText = totalNomsString;
		GameObject.Find("totalEnemiesString").guiText = totalEnemiesString;
		*/
	}
}

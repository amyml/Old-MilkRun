using UnityEngine;
using System.Collections;

public class scriptMovingTexture : MonoBehaviour {
	
	public enum VerticalMovement { Down = 0, Up = 1 }
	public enum HorizontalMovement { Left = 0, Right = 1 }
	public VerticalMovement verticalMovement = VerticalMovement.Down;
	public float verticalSpeed 		= 0.0f;
	public HorizontalMovement horizontalMovement = HorizontalMovement.Right;
	public float horizontalSpeed 	= 0.0f;
	
	public bool randomStartOffsetX 	= true;
	public bool randomStartOffsetY 	= false;
	
	private float offsetSpeedX 		= 0.0f;
	private float offsetSpeedY		= 0.0f;
	private int directionX			= 1;
	private int directionY 			= 1;


	// Use this for initialization
	void Start () {
		if(verticalMovement == VerticalMovement.Up)
			directionY = -1;
		if(horizontalMovement == HorizontalMovement.Right)
			directionX = -1;
		
		offsetSpeedX = horizontalSpeed / 100;
		offsetSpeedY = verticalSpeed / 100;
		
		if(randomStartOffsetX)
			renderer.material.mainTextureOffset += new Vector2(Random.value, 0);
		if(randomStartOffsetY)
			renderer.material.mainTextureOffset += new Vector2(0, Random.value);
	}
	
	// Update is called once per frame
	void Update () {
		renderer.material.mainTextureOffset += new Vector2(directionX * offsetSpeedX * Time.deltaTime, directionY * offsetSpeedY * Time.deltaTime);
	}
}

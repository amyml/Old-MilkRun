using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class ScriptProjectile : MonoBehaviour {
	
	public int team = 2;
	public bool ignoreGravity = true;
	//public float xVelocity = 1.0f;
	public float lifeTimeAfterDisarmed = 5.0f;
	public bool hasGravityAfterDisarmed = false;
	public bool isPingPong = false;
	
	public float damage = 101.0f;
	
	private Body body;
	private bool disarmed = false;
	private float timeTilDeletion = 9999.0f;
	
	
	// Use this for initialization
	void Start () {
		
		body = gameObject.GetComponent<FSBodyComponent>().PhysicsBody;
		
		body.IsBullet = true;
		
		body.IgnoreGravity = ignoreGravity;
		
		if(body.IgnoreGravity)
		{
			//body.LinearVelocity = new FVector2(body.LinearVelocity.X, 0.0f);
			body.GravityScale = 0.0f;
		}

		
		//body.LinearVelocity = new FVector2(xVelocity, body.LinearVelocity.Y);
		
		body.OnCollision += OnCollisionEvent;
	}
	
	// Update is called once per frame
	void Update () {
	
		if(disarmed)
		{
			timeTilDeletion -= Time.deltaTime;
			if(timeTilDeletion <= 0)
				GameObject.Destroy(gameObject);
		}
		
	}
	
	private bool OnCollisionEvent(Fixture FixtureA, Fixture FixtureB, Contact contact)
	{
		if(FixtureB.IsSensor)
			return false;
		
		if(disarmed)
		{
			return false;	
		}
		
		GameObject hitObject = FixtureB.Body.UserFSBodyComponent.gameObject;
		scriptHealth healthHitObject = hitObject.GetComponent<scriptHealth>();
		
		if(healthHitObject == null && hitObject.transform.parent != null )
		{
			healthHitObject = hitObject.transform.parent.GetComponent<scriptHealth>();
		}
		
		if( healthHitObject != null)
		{
			if( this.team == healthHitObject.team || healthHitObject.Dead())
			{
				return false;
			}
			if(healthHitObject.Dead())
			{
				return false;	
			}
			else
			{
				healthHitObject.Damage(damage);
			}
		}
		else
		{
			//Hit "scenery"
			if(!isPingPong)
				disarm();
			
		}		
		return true;	
	}
	
	public void disarm()
	{
		disarmed = true;
		if(hasGravityAfterDisarmed)
		{
			body.IgnoreGravity = false;
			body.GravityScale = 1.0f;
		}
		SetSelfDestructTimer();		
	}
	
	public void SetSelfDestructTimer()
	{
		timeTilDeletion = lifeTimeAfterDisarmed;
		
	}
	
	public void SetTeam(int t)
	{
		team = t;	
	}
	
	public int GetTeam()
	{
		return team;	
	}
}

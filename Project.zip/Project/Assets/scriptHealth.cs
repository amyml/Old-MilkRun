using UnityEngine;
using System.Collections;

public class scriptHealth : MonoBehaviour {

	public int team = 2;
	public float maxHealth = 100.0f;
	public float invulnerabilityTimeOnDamage = 1.0f;
	
		
	private float currHealth;
	private bool isDead = false;
	
	private float invulnTimer = 0.0f;
	private bool invulnTimerSet = false;
	private bool invulnerable = false;
	
	// Use this for initialization
	void Start () 
	{
		currHealth = maxHealth;
	}
	
	// Update is called once per frame
	void Update () 
	{

		//check if dead
		if( currHealth <= 0.0f )
		{
			if(!isDead) {
				isDead = true;	
			}
		}
		

		
		if(invulnTimerSet)
		{
			invulnTimer -= Time.deltaTime;
			if(invulnTimer <= 0.0f)
			{
				invulnerable = false;
				invulnTimerSet = false;
			}
		}
	
	}
	
	private void SetInvulnTimer()
	{
		if(invulnerabilityTimeOnDamage > 0.01)
		{
			invulnTimer = invulnerabilityTimeOnDamage;	
			invulnTimerSet = true;
			invulnerable = true;
		}

	}
	
	//---------------------------------------------
	//----MODIFIERS--------------------------------
	//---------------------------------------------	
	
	
	//Damage fails if target in invulnerable.
	//Returns true if target recieved damage.
	//Returns false if target is invulnrable and no damage was delt.
	public bool Damage(float damage) 
	{
		
		bool returnValue = !invulnerable;	
		
		if(damage > 0.0f)
		{
			
			if(!invulnerable)
			{

				scriptPowerUp power = gameObject.GetComponent<scriptPowerUp>();
				
				if(damage >= 10.0f && power != null && power.GetCurrPower() != scriptPowerUp.PowerUp.None)
				{
					power.SetCurrPower(scriptPowerUp.PowerUp.None);
				}
				
				currHealth -= damage;
				if( currHealth <= 0.0f )
				{
					isDead = true;	
				}
				else
				{
					SetInvulnTimer();
				}
			}
		}
		return returnValue;
	}
	
	
	//Ignores Invuln flag
	//Always succeeds in dealing damage.
	public void DamageBypassInvuln(float damage)
	{
		currHealth -= damage;
		if( currHealth <= 0.0f )
		{
			isDead = true;	
		}
	}
	
	public void Heal(float healz) 
	{
		currHealth += healz;
		if(currHealth > maxHealth)
		{
			currHealth = maxHealth;	
		}
	}
	
	public void SetHealthToMax()
	{
		currHealth = maxHealth;	
	}
	
	//instant death, bypasses damage flag
	public void Kill() 
	{
		currHealth = 0.0f;
		isDead = true;
	}
	
	public void SetMaxHealth(float newMaxHealth) 
	{
		maxHealth = newMaxHealth;
		if(currHealth > maxHealth)
		{
			currHealth = maxHealth;	
		}
	}
	
	
	
	//WARNING!!! These do not set the invulnrable timer!!
	
	public void SetInvulnerable()
	{
		invulnerable = true;	
	}
	
	public void SetInvulnerable(bool invuln)
	{
		invulnerable = invuln;	
	}
	
	
	//---------------------------------------------
	//----ACCESSORS--------------------------------
	//---------------------------------------------	
	public float GetCurrHealth()
	{
		return currHealth;	
	}
	
	public float GetMaxHealth()
	{
		return maxHealth;
	}
	
	public bool Dead()
	{
		return isDead;	
	}
	
	/*public bool GetDamageFlag()
	{
		return damageFlag;	
	}*/
	
	public bool IsInvulnerable()
	{
		return invulnerable;	
	}
	
	public int GetTeam()
	{
		return team;	
	}
	
	public void RestoreHealth()
	{
		currHealth = maxHealth;	
	}
}

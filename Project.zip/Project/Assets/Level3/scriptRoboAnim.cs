using UnityEngine;
using System.Collections;

public class scriptRoboAnim : MonoBehaviour {
	
	// Animations
    private Renderer moveRenderer;
    private OTAnimatingSprite moveSprite;	
	private Renderer deathRenderer;
    private OTAnimatingSprite deathSprite;	
	private Renderer fireRenderer;
    private OTAnimatingSprite fireSprite;
	private Renderer peckRenderer;
    private OTAnimatingSprite peckSprite;
	
	//Scripts
	scriptHealth charHealth;
	scriptRoboChickenController charControl;
	
	//Health loss related
	private float oldHealth;
	private float curHealth;
	
	//Mobility
	private bool busy;
	private bool hasDied;
	private bool hasPecked;
	
	// Use this for initialization
	void Start () {
		
		//health script
		charHealth = gameObject.GetComponent<scriptHealth>();
		//controller script
		charControl = gameObject.GetComponent<scriptRoboChickenController>();
		
		//animations
		moveRenderer = GameObject.Find("rcMove").renderer;
    	moveSprite = GameObject.Find("rcMove").GetComponent<OTAnimatingSprite>();	
		deathRenderer = GameObject.Find("rcDeath").renderer;
    	deathSprite = GameObject.Find("rcDeath").GetComponent<OTAnimatingSprite>();
		fireRenderer = GameObject.Find("rcFire").renderer;
    	fireSprite = GameObject.Find("rcFire").GetComponent<OTAnimatingSprite>();
		peckRenderer = GameObject.Find("rcPeck").renderer;
    	peckSprite = GameObject.Find("rcPeck").GetComponent<OTAnimatingSprite>();
	
		moveSprite.transform.renderer.material.mainTextureScale = new Vector3(0.25f, 0.25f, 1f);
		moveSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.75f);	
		

		deathSprite.transform.renderer.material.mainTextureScale = new Vector3(0.25f, 0.25f, 1f);
		deathSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.75f);
		
		fireSprite.transform.renderer.material.mainTextureScale = new Vector3(0.5f, 0.5f, 1f);
		fireSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.5f);	
		peckSprite.transform.renderer.material.mainTextureScale = new Vector3(0.25f, 0.25f, 1f);
		peckSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.75f);
		
		moveRenderer.enabled = true;
		deathRenderer.enabled = false;
		fireRenderer.enabled = false;
		peckRenderer.enabled = false;
		
		//Health
		oldHealth = charHealth.GetCurrHealth();
		curHealth = charHealth.GetCurrHealth();
		
		//Mobility
		busy = false;
		hasDied = false;
		hasPecked = false;
	}
	
	// Update is called once per frame
	void Update () {
		//Manage scaling and offset
		DisplayUpdate ();
		
		if (hasDied)
		{
			deathRenderer.enabled = true;
			moveRenderer.enabled = false;	
			fireRenderer.enabled = false;
			peckRenderer.enabled = false;	
		}
		else if (!hasDied && charHealth.Dead ())
		{
			deathRenderer.enabled = true;
			moveRenderer.enabled = false;	
			fireRenderer.enabled = false;
			peckRenderer.enabled = false;
			
			deathSprite.animation.fps = 4f;
			deathSprite.animation.duration = 1f;
			
			//Dying
			if(!deathSprite.isPlaying)
		    	deathSprite.Play();

			hasDied = true;
		}
		else if (!busy && charControl.ShouldKeepMoving())
		{
			moveRenderer.enabled = true;	
			deathRenderer.enabled = false;
			fireRenderer.enabled = false;
			peckRenderer.enabled = false;			
			//Moving
			if(!moveSprite.isPlaying)
		    	moveSprite.Play();
		}
		
	}
	
	//Changes the texture scale to correct dimensions
	private void DisplayUpdate(){
		moveSprite.transform.renderer.material.mainTextureScale = new Vector3(0.25f, 0.25f, 1f);
		moveSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.75f);
		

		deathSprite.transform.renderer.material.mainTextureScale = new Vector3(0.25f, 0.25f, 1f);
		deathSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.75f);
		
		fireSprite.transform.renderer.material.mainTextureScale = new Vector3(0.5f, 0.5f, 1f);
		fireSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.5f);
		peckSprite.transform.renderer.material.mainTextureScale = new Vector3(0.25f, 0.25f, 1f);
		peckSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.75f);
	}
	
	public void StartPeck()
	{
		if (hasDied)
		{
			if (!deathSprite.isPlaying)
			{
				fireRenderer.enabled = false;
				moveRenderer.enabled = false;	
				peckRenderer.enabled = false;
			}
		}
		else
		{
			if (!hasPecked)
			{
				peckRenderer.enabled = true;
				moveRenderer.enabled = false;	
				deathRenderer.enabled = false;
				fireRenderer.enabled = false;			
				//Pecking
				if(!peckSprite.isPlaying)
				{
		    		peckSprite.Play();
					hasPecked = true;
				}		
				StartCoroutine(Peck ());
			}
		}
	}
	
	private IEnumerator Peck()
	{
		busy = true;		
		//Allow time to peck
		yield return new WaitForSeconds(0.75f);	
		busy = false;
	}
	
	public void StartFireball()
	{
		if (hasDied)
		{
			if (!deathSprite.isPlaying)
			{
				fireRenderer.enabled = false;
				moveRenderer.enabled = false;	
				peckRenderer.enabled = false;
			}
		}
		else{
			if (!busy && !hasPecked)
			{
				fireRenderer.enabled = true;
				moveRenderer.enabled = false;	
				deathRenderer.enabled = false;
				peckRenderer.enabled = false;		
				//Spitting fire
				if(!fireSprite.isPlaying){
		    		fireSprite.Play();
				}	
				StartCoroutine(Fireball ());
				}
		}
	}
	
	private IEnumerator Fireball()
	{
		busy = true;		
		//Allow time to fire shoot
		yield return new WaitForSeconds(0.25f);		
		busy = false;
	}
}
using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptRoboChickenController : MonoBehaviour {
	
	private Body body;
	public bool movingForward = false;  //MELODY -- THIS BOOLEAN WILL BE USEFUL FOR RUNNING ANIMATION
	
	public float movementSpeed = 6.0f;
	public float fireballFrequency = 2.0f;
	
	public float endingPosX = 167.713f;
	
	public Vector3 startingPos = new Vector3(-6,1,0);
	public float jumpHeight = 5.0f;
	public float jumpSpeed = 6.0f;
	public float scaleSpeedUp = 1.008f;
	public float scaleSpeedDown = 1.035f;
	
	scriptRoboAnim animScript;
	
	private ScriptProjectileWeapon weapon;
	private bool dead;

	// Use this for initialization
	void Start () 
	{
		dead = false;
		animScript = gameObject.GetComponent<scriptRoboAnim>();
		
		weapon = gameObject.GetComponent<ScriptProjectileWeapon>();
		
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.OnCollision += OnCollisionEvent;
		
		movingForward = false;
		
		AwakeRoboChicken();
	}
	
	// Update is called once per frame
	void Update () 
	{
		dead = gameObject.GetComponent<scriptHealth>().Dead ();
	}
	
	public void AwakeRoboChicken() {
		StartCoroutine ("EnterLevel");
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		if((string) fixtureB.Body.UserData == "Player") {
			CancelInvoke("MoveForward");
			StopMovingForward();
			Peck();
		}
		
		// DeathBox object results in automatic character death
		scriptHealth deadCharHealth = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptHealth>();
		if(deadCharHealth != null)
		{
			deadCharHealth.Kill();	
		}
		
		return true;
	}
	
	private void Peck() {	
		animScript.StartPeck();
	}
	
	private void StopMovingForward() {
		movingForward = false;
		body.LinearVelocity = new FVector2(0, 0);
	}
	
	public bool ShouldKeepMoving() {
		if(transform.position.x >= endingPosX) {
			return false;
		}
		return true;
	}
	
	private IEnumerator MoveForward()
	{
		movingForward = true;
		while (ShouldKeepMoving()) {
			
            body.LinearVelocity = new FVector2(movementSpeed, 0);
            yield return null;
        }
		StopMovingForward();
	}
	
  	IEnumerator LaunchFireball() 
	{
		while (!dead) {
			animScript.StartFireball();
			weapon.FireShot();
			yield return new WaitForSeconds(fireballFrequency);
		}
    }
	
  	IEnumerator EnterLevel() 
	{
		float originalY = transform.position.y;
		Vector3 originalScale = transform.localScale;
		
		transform.localScale = originalScale/3;
		body.SetTransform(new FVector2(startingPos.x, startingPos.y), 0);
		
		while(transform.position.y < jumpHeight) {
			if(transform.localScale.x < originalScale.x/2.0f)
			{
				transform.localScale = transform.localScale*scaleSpeedUp;
			}
			body.LinearVelocity = new FVector2(0, jumpSpeed);
			yield return new WaitForSeconds(0.001f);
		}
		while(transform.position.y > originalY) {
			if(transform.localScale.x < originalScale.x)
			{
				transform.localScale = transform.localScale*scaleSpeedDown;
			}
			body.LinearVelocity = new FVector2(0, -1*jumpSpeed);
			yield return new WaitForSeconds(0.001f);
		}
		
		body.LinearVelocity = new FVector2(0, 0);
		
		StartCoroutine ("MoveForward");
		StartCoroutine("LaunchFireball");
		yield return null;
    }
	/*
	private IEnumerator MoveForward()
	{
		yield return new WaitForSeconds(delay);
		
		Application.LoadLevel(nextLevel);	
	}
	
  	void LaunchFireball() {
        Rigidbody instance = Instantiate(projectile);
        instance.velocity = Random.insideUnitSphere * 5;
    }
    void Example() {
        InvokeRepeating("LaunchProjectile", 2, 0.3F);
    }
    */
}

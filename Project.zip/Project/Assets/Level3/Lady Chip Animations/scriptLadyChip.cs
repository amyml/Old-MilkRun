using UnityEngine;
using System.Collections;

public class scriptLadyChip : MonoBehaviour {
	
	// Animations
    private Renderer sadRenderer;
    private OTAnimatingSprite sadSprite;
    private Renderer happyRenderer;
    private OTAnimatingSprite happySprite;

	// Use this for initialization
	void Start () {
		
		//Attach animations to sprites
		sadRenderer = GameObject.Find("lcSad").renderer;
    	sadSprite = GameObject.Find("lcSad").GetComponent<OTAnimatingSprite>();
		happyRenderer = GameObject.Find("lcHappy").renderer;
    	happySprite = GameObject.Find("lcHappy").GetComponent<OTAnimatingSprite>();
		
		sadRenderer.enabled = true;
		happyRenderer.enabled = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (GameObject.FindGameObjectWithTag("Robochicken").gameObject.GetComponent<scriptHealth>().Dead())
		{
			happyRenderer.enabled = true;
			sadRenderer.enabled = false;
			if (!happySprite.isPlaying)
				happySprite.Play ();
		}
	}
}

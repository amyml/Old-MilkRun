using UnityEngine;
using System.Collections;

public class scriptGlobalInformation : MonoBehaviour {
	
	public int totalCoinsCollected;
	public int totalNomsEaten;
	public int totalEnemiesDefeated;
	public bool bowAchievement = false;
	public bool pictureAchievement = false;
	public int levelUnlocked = 0;
	
	
	void Awake () {
        DontDestroyOnLoad(transform.gameObject);
		levelUnlocked = 0;
    }
	
	// Use this for initialization
	void Start () {
		totalEnemiesDefeated = 0;
		totalCoinsCollected = 0;
		totalCoinsCollected = 0;
		bowAchievement = false;
		pictureAchievement = false;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

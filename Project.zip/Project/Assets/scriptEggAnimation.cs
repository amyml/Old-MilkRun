using UnityEngine;
using System.Collections;

public class scriptEggAnimation : MonoBehaviour {
	
	
    // Animations
    private Renderer moveRenderer;
    private OTAnimatingSprite moveSprite;
    private Renderer deathRenderer;
    private OTAnimatingSprite deathSprite;
	private Renderer attackRenderer;
    private OTAnimatingSprite attackSprite;
	
	private Component[] sprites;
	
	//Directions
    private int currFacingDir = 1;
	private int lastFacingDir = 2;
	
	//Mobility
	private bool movable;
	
	private int LEFT = 1;
	//private int RIGHT = 2;
		
	//Scripts
	private scriptEggController eggScript;
	private ScriptEggCollision eggCollision;
	private bool attacked;
	
	//Transform Scale
	private float x = 0.0f;
	private float y = 0.0f;
	private float z = 0.0f;

	
	// Use this for initialization
	void Start () {
		
		//Scripts		
		eggScript = gameObject.GetComponent<scriptEggController>();
		eggCollision = gameObject.GetComponent<ScriptEggCollision>();
		
    	//Alive and movable
		movable = true;
		attacked = false;
		
		//Sprites & Rendering Sprites
		sprites = GetComponentsInChildren<OTAnimatingSprite>();
		
		foreach (OTAnimatingSprite s in sprites){
			if(s.tag == "EggMove")
				moveSprite = s;
			else if (s.tag == "EggDeath"){
				deathSprite = s;
				x = s.transform.localScale.x;
				y = s.transform.localScale.y;
				z = s.transform.localScale.z;
			}
			else if (s.tag == "EggAttack")
				attackSprite = s;
		}
		
		moveRenderer = moveSprite.renderer;    	
    	moveRenderer.enabled = true;
		
		deathRenderer = deathSprite.renderer;
    	deathRenderer.enabled = false;	
		
		attackRenderer = attackSprite.renderer;
    	attackRenderer.enabled = false;	
		
	}
	
	// Update is called once per frame
	void Update () {
	
		//Directions
		currFacingDir = eggScript.GetDirection();
		
		if(currFacingDir != lastFacingDir && movable)
		{
			
			if(eggScript.GetDirection() == LEFT)
			{
				//facing left
				moveSprite.transform.localScale = new Vector3(-x, y, z);//-3.5f, 8.5f, 3f
				deathSprite.transform.localScale = new Vector3(-x, y, z);
				attackSprite.transform.localScale = new Vector3(-x, y, z);
			}
			else
			{
				//facing right
				moveSprite.transform.localScale = new Vector3(x, y, z); //3.5f, 8.5f, 3f
				deathSprite.transform.localScale = new Vector3(x, y, z);
				attackSprite.transform.localScale = new Vector3(x, y, z);
			}
			
		}
		
		//Update direction
		lastFacingDir = currFacingDir;
		
		//Player death animation
		if (!eggCollision.IsAlive())
		{	

			moveRenderer.enabled = false;
			attackRenderer.enabled = false;
			deathRenderer.enabled = true;
			
			//Kill all movements
			movable = false;
			
			//Kill all acceleration
			eggScript.jumpForceVertical = 0f;
			eggScript.jumpForceHorizontal = 0f;
			eggCollision.damageToPlayer = 0f;
			
			deathSprite.animation.fps = 8f; //4f;
			deathSprite.animation.duration = 0.8f; //1.5f;
				
			if(!deathSprite.isPlaying)
       	   		deathSprite.Play();
			
		}
		else
		{
			if (movable && (!attacked))
			{
				
				//Enemy egg is moving an attacking
				
				deathRenderer.enabled = false;
				attackRenderer.enabled = false;
				moveRenderer.enabled = true;
				
				moveSprite.animation.fps = 8f;
				moveSprite.animation.duration = 0.5f;
				
				if(!moveSprite.isPlaying)
	       	   		moveSprite.Play("move");
				
			}		
		}
	}
	
	//Called by ScriptEggCollision whenever egg deals damage to player
	public void AttackAnim()
	{
		//Hit player
			
		deathRenderer.enabled = false;
		moveRenderer.enabled = false;
		attackRenderer.enabled = true;
			
		attackSprite.animation.fps = 2f;
		attackSprite.animation.duration = 0.25f;
							
		if(!attackSprite.isPlaying)
			attackSprite.Play();
			
		StartCoroutine(Hit ());
	}
	
	//Stalls normal animation for egg to display attack satisfaction
	private IEnumerator Hit()
	{
		attacked = true;
		
		//Allow time for hit satisfaction
		yield return new WaitForSeconds(0.25f);
		
		attacked = false;
		attackRenderer.enabled = false;
		moveRenderer.enabled = true;
	}
}
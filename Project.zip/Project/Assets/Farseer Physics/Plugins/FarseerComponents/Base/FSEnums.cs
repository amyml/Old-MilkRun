using UnityEngine;
using System.Collections;

public enum FSShapePointInput
{
	Vector2List,
	Transform
}
public enum CollisionGroupDef
{
	None,
	PresetFile,
	Manually
}
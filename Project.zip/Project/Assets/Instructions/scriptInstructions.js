/* var thisSkin : GUISkin;

function OnGUI ()
{
	GUI.skin = thisSkin;

	GUI.color = Color.black;
	
	var InsText : String = "INSTRUCTIONS";
	GUI.Label(Rect(Screen.width-850,70,600,45), InsText);
	
	var MoveText : String = "Move: Left/Right Arrows";
	GUI.Label(Rect(Screen.width-1000,170,600,45), MoveText);
	
	var SprintText : String = "Sprint: Shift + Arrows";
	GUI.Label(Rect(Screen.width-1000,270,600,45), SprintText);
	
	var JumpText : String = "Jump: Spacebar";
	GUI.Label(Rect(Screen.width-1000,370,600,45), JumpText);
	
	var DJumpText : String = "Double Jump: Spacebar + Spacebar (with PowerUp)";
	GUI.Label(Rect(Screen.width-1000,470,600,90), DJumpText);
	
	var PauseText : String = "Pause: Escape";
	GUI.Label(Rect(Screen.width-1000,570,600,45), PauseText);
}*/
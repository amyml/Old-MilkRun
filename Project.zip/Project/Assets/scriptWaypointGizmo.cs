using UnityEngine;
using System.Collections;

public class scriptWaypointGizmo : MonoBehaviour {
	
	public string fileName = "waypoint.png";
	public bool allowScaling = false;


	void OnDrawGizmos() {
		Gizmos.DrawIcon(transform.position, fileName, allowScaling);
	}
}

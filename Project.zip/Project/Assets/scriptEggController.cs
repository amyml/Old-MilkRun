using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FarseerPhysics.Collision.Shapes;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptEggController : MonoBehaviour {
	//script Master!!
	private scriptMaster scriptMaster;
	//Physics World
	private World physicsWorld;
	
	private Body body;
	public Transform target;
	
	public float jumpForceVertical = 150.0f;
	public float jumpForceHorizontal = 100.0f;
	public float attackRangeHorizontal = 10.0f;
	public float attackRangeVertical = 10.0f;
	
	public bool smartJump = true; //When closer to target, jump smaller more accurate amounts
	public float distToSmartJump = 3.0f; //When this distance to target, jump in smaller intelligent increments than normal
	
	public bool returnsToOriginalPos = true; //Egg will go back to original position when player exits range from its original position
											 //Otherwise if false, the egg will continually chase the player as long as within range
	public float originalPositionEpsilon = 0.5f; //Leeway for how close to the original position the egg has to get before stopping
	private float originalPositionX; //Original coordinates for where the egg "returns" to
	private float originalPositionY;
	public float jumpWaitTime = 5.0f;
	private float jumpTimer;
	
	private int facingDir = 2; //left is 1; right is 2
	
	
	
	void Start () {
		//ScriptMaster
		//scriptMaster = (scriptMaster)(GameObject.Find("Main Camera").GetComponent("scriptMaster"));		
		//physicsWorld = FSWorldComponent.PhysicsWorld;
		
		//Setting the main body
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.Mass = 0.0f;
		body.FixedRotation = true;
		originalPositionX = this.transform.position.x;
		originalPositionY = this.transform.position.y;
		
		
		jumpTimer = jumpWaitTime;
	}
	
	// Update is called once per frame
	void Update () {
		if(target)
		{
			if(returnsToOriginalPos)
			{
				Vector3 original = new Vector3(originalPositionX, originalPositionY, 0);
				Vector2 targetVector = target.position - original;
				float distanceToTarget = targetVector.magnitude;
				Vector2 directionToTarget = targetVector / distanceToTarget;  //normalized vector to target
				float direction = 0;
				
				//Within range of its original position
				if(Mathf.Abs(targetVector.x) <= attackRangeHorizontal && Mathf.Abs(targetVector.y) <= attackRangeVertical)
				{
					targetVector = target.position - this.transform.position;
					distanceToTarget = targetVector.magnitude;
					directionToTarget = targetVector / distanceToTarget;  //normalized vector to target
					
					if(!facingTarget(directionToTarget)) //turn towards the target/player
						turnDirection();
					
					direction = directionToTarget.x;
					jumpAt(direction, distanceToTarget);
				}
				else
				{
					Vector2 returnVector = original - this.transform.position;
					float distanceToOrigin = returnVector.magnitude;
					Vector2 directionToOrigin = returnVector / distanceToOrigin; //normalized vector to origin
					if(Mathf.Abs(returnVector.x) > originalPositionEpsilon) //Only move if you are not in original position
					{
						if(!facingTarget(directionToOrigin)) //turn towards the original position
							turnDirection();
						
						direction = directionToOrigin.x;
						jumpAt(direction, distanceToOrigin);
					}
				}
			}
			else
			{
				Vector2 targetVector = target.position - this.transform.position;
				float distanceToTarget = targetVector.magnitude;
				Vector2 directionToTarget = targetVector / distanceToTarget;  //normalized vector to target
				float dir = directionToTarget.x;
				
				if(Mathf.Abs(targetVector.x) <= attackRangeHorizontal && Mathf.Abs(targetVector.y) <= attackRangeVertical)
				{
					if(!facingTarget(directionToTarget)) //turn towards the target/player
						turnDirection();
					
					jumpAt(dir, distanceToTarget);
				}
			}
		}
		else
		{
			
		}
	}
	
	void jumpAt(float dir, float distance) {
		jumpTimer -= Time.deltaTime;
		if(jumpTimer <= 0)
		{
			if(smartJump)
			{
				float jumpPercentage = 1.00f; //Fraction of his normal jump force that he will use
				if(distance <= distToSmartJump)
					jumpPercentage = distance/distToSmartJump;
				body.ApplyForce(new FVector2(dir*jumpForceHorizontal*jumpPercentage, jumpForceVertical));
			}
			else
			{
				body.ApplyForce(new FVector2(dir*jumpForceHorizontal, jumpForceVertical));
			}
			jumpTimer = jumpWaitTime;
		}
	}
	
	bool facingTarget(Vector2 directionToTarget) {
		float toTarget = directionToTarget.x; //negative means to its left, positive means to its right
		if(toTarget < 0 && facingDir == 1 || toTarget > 0 && facingDir == 2)
			return true;
		else 
			return false;
	}
	
	void turnDirection(){
		if(facingDir == 1)
			facingDir = 2;
		else
			facingDir = 1;
	}
	
	public int GetDirection()
	{
		return facingDir;
	}
}

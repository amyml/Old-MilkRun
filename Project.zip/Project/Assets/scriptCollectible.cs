using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FarseerPhysics.Collision.Shapes;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptCollectible : MonoBehaviour {
	
	
	private Body body;
	private scriptStatTracker scriptStatTracker;
	private bool collected = false;
	
	private scriptSoundsPlayer scriptSoundsPlayer;

	void Start () {
		
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.IsSensor = true;
		body.OnCollision += OnCollisionEvent;
		scriptStatTracker = (scriptStatTracker)(GameObject.Find("prefabStatTracker").GetComponent("scriptStatTracker"));
		scriptSoundsPlayer = (scriptSoundsPlayer)(GameObject.Find("Sounds").GetComponent("scriptSoundsPlayer"));
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		//A = you
		//B = them
		if(fixtureB.Body.UserFSBodyComponent.gameObject.tag == "MrMilk")
		{	
			if(!collected)
			{
				scriptStatTracker.DecreaseCollectibleCount();
				collected = true;
				scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.COIN);
			}
			GameObject.Destroy(this.gameObject);
		}
		
		
		return true;
	}
	
}

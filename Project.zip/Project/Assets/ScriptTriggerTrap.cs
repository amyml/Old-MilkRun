using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;

public class ScriptTriggerTrap : MonoBehaviour {
	
	public GameObject objectHingeLeft;
	public GameObject objectHingeRight;
	
	private Body leftHinge;
	private Body rightHinge;
	
	private Body triggerBody;
	
	private bool isTriggered = false; // has the trigger been activated by stimuli?
	private bool isActive = false; //is the trigger capable of receiving stimuli
	
	
	// Use this for initialization
	void Start () {
	
		leftHinge = objectHingeLeft.GetComponent<FSBodyComponent>().PhysicsBody;
		rightHinge = objectHingeRight.GetComponent<FSBodyComponent>().PhysicsBody;
		
		triggerBody = gameObject.GetComponent<FSBodyComponent>().PhysicsBody;
		triggerBody.IsSensor = true;
		
		triggerBody.OnCollision += OnCollisionEvent;;
	}
	
	// Update is called once per frame
	void Update () {
		
		if(isTriggered && isActive)
		{
			leftHinge.IsStatic = false;
			rightHinge.IsStatic = false;
			
			isActive = false;
			isTriggered = false;
		}
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		if(fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<ScriptCharCollisions>() !=null)
		{
			isTriggered = true;
		}
		
		return false;
	}

	public void SetActive(bool t)
	{
		isActive = t;	
	}
	
	public void SetActive()
	{
		isActive = true;	
	}
}

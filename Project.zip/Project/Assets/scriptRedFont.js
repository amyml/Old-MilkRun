#pragma strict

function Start () {
	this.renderer.material.color = Color.red;
}

function Update () {

}
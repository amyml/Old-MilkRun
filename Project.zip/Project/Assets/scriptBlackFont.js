#pragma strict

function Start () {
	this.renderer.material.color = Color.black;
}

function Update () {

}
using UnityEngine;
using System.Collections;

public class scriptInstructionDisplay : MonoBehaviour {
	
	GameObject player;
	ScriptCharAnimation animScript;
	scriptTextAnimation scriptTextAnimation;
	bool visible = false;
	
	// Use this for initialization
	void Start () {
		player = GameObject.FindGameObjectWithTag("MrMilk");
		animScript = player.GetComponent<ScriptCharAnimation>();
		scriptTextAnimation = this.GetComponent<scriptTextAnimation>();
		gameObject.renderer.enabled = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (animScript.GetPowerStatus() != visible)
		{
			visible = animScript.GetPowerStatus();
			if (visible) {
				gameObject.renderer.enabled = true;
				if(scriptTextAnimation != null)
				{
					scriptTextAnimation.ActivateAnimation();
				}
			}
		}
	}
}

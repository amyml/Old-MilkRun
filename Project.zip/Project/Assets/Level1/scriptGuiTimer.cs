using UnityEngine;
using System.Collections;

public class scriptGuiTimer : MonoBehaviour {
	
	// amount of time the game has lasted
	public float gameTime = 0.0f;
	public GUISkin mySkin;
	
	private bool timeFinished = false;
	private string timerDisplayString = "";
	
	// Update is called once per frame
	void Update () {
		gameTime += Time.deltaTime;
	}
	
	public void EndTimer() {
		timeFinished = true;	
	}
	
	void OnGUI ()
	{
		GUI.skin = mySkin;
		GUI.color = Color.black;
		float secsLeft = gameTime;
		
		if(timeFinished) {
			//GUI.Label(new Rect(Screen.width-250,10,400,50), timerDisplayString);
		} 
		else {
			int hours = (int)Mathf.Floor(secsLeft) / 3600;
			secsLeft -= hours * 3600;
			int minutes = (int)Mathf.Floor(secsLeft) / 60;
			secsLeft -= minutes * 60;
			int seconds  = (int)Mathf.Floor(secsLeft);
			secsLeft -= seconds * 1;
			int milliseconds = (int)Mathf.Round(secsLeft * 1000);
			
			string hoursString = "" + hours;
			if(hoursString.Length < 2)
				hoursString = "0" + hoursString;
			string minutesString = "" + minutes;
			if(minutesString.Length < 2)
				minutesString = "0" + minutesString;
			string secondsString = "" + seconds;
			if(secondsString.Length < 2)
				secondsString = "0" + secondsString;
			
			timerDisplayString = hoursString + ":" + minutesString + ":" + secondsString + ":" + milliseconds;
			GUI.Label(new Rect(Screen.width-250,10,400,50), timerDisplayString);
		}
	}
	
	public float GetSeconds() {
		return gameTime;
	}
	
	public string GetTimeString() {
		float secsLeft = gameTime;
		int hours = (int)Mathf.Floor(secsLeft) / 3600;
		secsLeft -= hours * 3600;
		int minutes = (int)Mathf.Floor(secsLeft) / 60;
		secsLeft -= minutes * 60;
		int seconds  = (int)Mathf.Floor(secsLeft);
		secsLeft -= seconds * 1;
		int milliseconds = (int)Mathf.Round(secsLeft * 1000);
		
		string hoursString = "" + hours;
		if(hoursString.Length < 2)
			hoursString = "0" + hoursString;
		string minutesString = "" + minutes;
		if(minutesString.Length < 2)
			minutesString = "0" + minutesString;
		string secondsString = "" + seconds;
		if(secondsString.Length < 2)
			secondsString = "0" + secondsString;
		
		string timerDisplayString = hoursString + ":" + minutesString + ":" + secondsString + ":" + milliseconds;	
		return timerDisplayString;
	}
}

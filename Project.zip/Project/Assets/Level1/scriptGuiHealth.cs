using UnityEngine;
using System.Collections;

public class scriptGuiHealth : MonoBehaviour {
	
    public float progress 		= 0.0f;
    public Vector2 pos 		= new Vector2(20,10);
    public Vector2 size 		= new Vector2(80, 200); //specifically scaled to fit texture, 130, 78
    public Texture2D progressBarEmpty = null;
    public Texture2D progressBarFull = null;
    
    public Texture2D progressBarChocEmpty = null;
    public Texture2D progressBarChocFull = null;
	
	public Texture2D progressBarStrawEmpty = null;
    public Texture2D progressBarStrawFull = null;
	
	public Texture2D hurtBarEmpty = null;
    public Texture2D hurtBarFull = null;
	
	private ScriptCharAnimation ScriptCharAnimation;
	private scriptHealth scriptHealth;
	
	private float maxHealth;
	
	private float curHealth;
	private float pastHealth;
	private bool hurt = false;
	
	public float cartonTopPercent = 0.28f;
	
	void Start() {
		ScriptCharAnimation = (ScriptCharAnimation)(gameObject.GetComponent("ScriptCharAnimation"));	
		scriptHealth = (scriptHealth)(gameObject.GetComponent("scriptHealth"));
		
		maxHealth = scriptHealth.maxHealth * 0.01f;
		
		curHealth = maxHealth;
		pastHealth = curHealth;
	}
	
    void OnGUI()
    {
		float remainingCartonPercent = (1.0f - cartonTopPercent);
		float lifeProgress = progress * remainingCartonPercent;
		
		if (hurt)
		{
			GUI.DrawTexture(new Rect(pos.x, pos.y, size.x, size.y), hurtBarFull);
			GUI.BeginGroup(new Rect (pos.x, pos.y, size.x, size.y * Mathf.Clamp01(1.0f - lifeProgress)));
			GUI.DrawTexture(new Rect(0, 0, size.x, size.y), hurtBarEmpty);
			/*
			GUI.DrawTexture(new Rect(pos.x, pos.y, size.x, size.y), hurtBarEmpty);
    		GUI.BeginGroup(new Rect (pos.x, pos.y, size.x, size.y * Mathf.Clamp01(progress)));
    		GUI.DrawTexture(new Rect(0, 0, size.x, size.y), hurtBarFull);
    		*/
		}
        // In the future this will need to be modified to accommondate future power-ups 	
    	else if (ScriptCharAnimation.GetPowerStatus())
    	{
			if (ScriptCharAnimation.GetPowerType() == 0f)
			{
				GUI.DrawTexture(new Rect(pos.x, pos.y, size.x, size.y), progressBarChocFull);
				GUI.BeginGroup(new Rect (pos.x, pos.y, size.x, size.y * Mathf.Clamp01(1.0f - lifeProgress)));
				GUI.DrawTexture(new Rect(0, 0, size.x, size.y), progressBarChocEmpty);
				/*
    			GUI.DrawTexture(new Rect(pos.x, pos.y, size.x, size.y), progressBarChocEmpty);
    			GUI.BeginGroup(new Rect (pos.x, pos.y, size.x, size.y * Mathf.Clamp01(progress)));
    			GUI.DrawTexture(new Rect(0, 0, size.x, size.y), progressBarChocFull);
    			*/
			}
			else if (ScriptCharAnimation.GetPowerType() == 1f)
			{
				GUI.DrawTexture(new Rect(pos.x, pos.y, size.x, size.y), progressBarStrawFull);
				GUI.BeginGroup(new Rect (pos.x, pos.y, size.x, size.y * Mathf.Clamp01(1.0f - lifeProgress)));
				GUI.DrawTexture(new Rect(0, 0, size.x, size.y), progressBarStrawEmpty);
				/*
				GUI.DrawTexture(new Rect(pos.x, pos.y, size.x, size.y), progressBarStrawEmpty);
    			GUI.BeginGroup(new Rect (pos.x, pos.y, size.x, size.y * Mathf.Clamp01(progress)));
    			GUI.DrawTexture(new Rect(0, 0, size.x, size.y), progressBarStrawFull);
    			*/
			}
    	}
    	else
    	{
			GUI.DrawTexture(new Rect(pos.x, pos.y, size.x, size.y), progressBarFull);
			GUI.BeginGroup(new Rect (pos.x, pos.y, size.x, size.y * Mathf.Clamp01(1.0f - lifeProgress)));
			GUI.DrawTexture(new Rect(0, 0, size.x, size.y), progressBarEmpty);
    	}
    	
    	GUI.EndGroup();
    }
     
    void Update()
    {
    	progress = scriptHealth.GetCurrHealth() * 0.01f;
		
		curHealth = scriptHealth.GetCurrHealth ();
		if (curHealth != pastHealth){
			hurt = true;
			print ("hurt!");
		}
		else {
			hurt = false;	
		}
		
		pastHealth = curHealth;
    }
}

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using FarseerPhysics.Dynamics;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Collision.Shapes;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptOneWayPlatform : MonoBehaviour {
	
	private Body body;
	private Fixture topCollider;
	private List<Contact> topContacts;

	private Fixture platformBody;
	
	// Use this for initialization
	void Start () {
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.OnCollision += OnCollisionEvent;
		
		platformBody = body.FixtureList[0];
		topContacts = new List<Contact>();
		//topCollider = body.FixtureList[1];
		//topCollider.IsSensor = true;
		//mainBody.IsSensor = true;
		
		Shape rect = body.FixtureList[0].Shape;
		
		//rect.
	}
	
	// Update is called once per frame
	void Update () {
		//CheckTopContacts();
		
	}
	
	private void CheckTopContacts()
	{
		//Check if the character is grounded
		if(topContacts.Count < 1)
		{
			
		} 
		else
		{
			foreach(Contact topContact in topContacts)
			{
				bool isTouching = topContact.IsTouching();
				if(isTouching) {
					break;	
				}
			}
			for(int i = 0; i < topContacts.Count; i++)
			{
				if(!topContacts[i].IsTouching())
				{
					topContacts.RemoveAt(i);
					i = Mathf.Max(0, i - 1);
				}
			}
		}	
	}		
	
	
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		if(fixtureA == platformBody && !(fixtureB.Body.IsStatic) )
		{
			if(fixtureB.Body.LinearVelocity.Y >= 0.001f)
			{
				return false;	
			}
	
			if( fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptEggController>() == null)
			{
				if( fixtureB.Body.GetWorldPoint(new FVector2(0,0)).Y  > 0.5f + fixtureA.Body.GetWorldPoint(new FVector2(0,0)).Y )//+ 0.01f + fixtureB.Shape.Radius)
				{		
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				if( fixtureB.Body.GetWorldPoint(new FVector2(0,0)).Y  > fixtureA.Body.GetWorldPoint(new FVector2(0,0)).Y + fixtureB.Shape.Radius)//+ 0.01f + fixtureB.Shape.Radius)
				{		
					return true;
				}
				else
				{
					return false;
				}
				
			}
		}
		return true;
	}
	
	
	
}

using UnityEngine;
using System.Collections.Generic;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptAchievement : MonoBehaviour {

	private Body body;
	
	void Start()
	{
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.OnCollision += OnCollisionEvent;
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		// Achievement sets character's health to max
		scriptHealth mainChar = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptHealth>();
		if(mainChar != null && mainChar.tag == "MrMilk")
		{
			mainChar.RestoreHealth();	
		}
		
		return true;
	}
}

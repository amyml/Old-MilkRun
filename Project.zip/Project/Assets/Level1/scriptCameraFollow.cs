using UnityEngine;
using System.Collections;

public class scriptCameraFollow : MonoBehaviour {

	/*
	 * This script is for making the Main Camera follow the 
	 * player along the X axis, and sizing up when the player
	 * moves too high vertically.
	 */
	
	public GameObject mainPlayer;
	public float cameraLeftLimit				 = -2.0f;
	public float cameraRightLimit				 = 114.0f;
	public float cameraDefaultY 				 = 2.0f;
	public float cameraDefaultZ 				 = -70.0f;
	public float cameraDefaultSize				 = 3.5f;
	public float verticalMovementThreshold 		 = 4.0f;
	public float cameraExpandAmount				 = 0.4f;
	public float cameraClimbAmount				 = 0.5f;
	
	
	void Start ()
	{
		this.camera.orthographicSize = cameraDefaultSize;
	}
	
	void Update () 
	{
		Transform cameraTransform = this.gameObject.transform;
		Transform playerTransform = mainPlayer.gameObject.transform;
		
		float newCameraY = cameraDefaultY;
	
		//Check the players y-coordinate and scale up camera if above threshold
		if(playerTransform.position.y <= verticalMovementThreshold)
		{
			this.camera.orthographicSize = cameraDefaultSize;
		}
		else //Over the threshold, update size and y-position
		{
			this.camera.orthographicSize = cameraDefaultSize + cameraExpandAmount*(playerTransform.position.y - verticalMovementThreshold);
			newCameraY += cameraClimbAmount*(playerTransform.position.y - verticalMovementThreshold);
		}
		
		
		//Follow the player's x-position
		
		float playerX = playerTransform.position.x;
		if(playerX > cameraLeftLimit && playerX < cameraRightLimit) {
			cameraTransform.position = new Vector3(playerX, newCameraY, cameraDefaultZ);
			//cameraTransform.position = Vector3.Lerp(cameraTransform.position, new Vector3(playerX, newCameraY, cameraDefaultZ), Time.deltaTime * 100000);
		}
		else if(playerX <= cameraLeftLimit)
			cameraTransform.position = new Vector3(cameraLeftLimit, newCameraY, cameraDefaultZ);
		else if(playerX >= cameraRightLimit)
			cameraTransform.position = new Vector3(cameraRightLimit, newCameraY, cameraDefaultZ);
		
	}
	
	public void Disable() {
		this.enabled = false;
	}
	
}

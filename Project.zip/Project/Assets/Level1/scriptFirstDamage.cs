using UnityEngine;
using System.Collections;

public class scriptFirstDamage : MonoBehaviour {
	
	private GameObject player;
	private bool firstDamageOccurred = false;
	
	private float maxHealth;
	private scriptHealth scriptHealth;
	scriptTextAnimation scriptTextAnimation;
	
	//public GameObject planeAvoidCollisions;

	// Use this for initialization
	void Start () {
		player = GameObject.FindGameObjectWithTag("MrMilk");
		scriptHealth = (scriptHealth)(player.GetComponent("scriptHealth"));
		maxHealth = scriptHealth.GetMaxHealth();
	}
	
	// Update is called once per frame
	void Update () {
		float currHealth = scriptHealth.GetCurrHealth();
		if(currHealth < maxHealth && firstDamageOccurred == false)
		{
			firstDamageOccurred = true;
			//if(planeAvoidCollisions != null) {
				scriptTextAnimation = this.GetComponent<scriptTextAnimation>();
				scriptTextAnimation.ActivateAnimation();
			//}
		}
	}
}

using UnityEngine;
using System.Collections.Generic;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptDeathBox : MonoBehaviour {
		
	
	private Body body;
	
	void Start()
	{
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.OnCollision += OnCollisionEvent;
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		// DeathBox object results in automatic character death
		scriptHealth deadChar = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptHealth>();
		if(deadChar != null)
		{
			deadChar.Kill();	
		}
		
		return true;
	}
	
	
}

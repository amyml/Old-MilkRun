using UnityEngine;
using System.Collections;

public class scriptStatTracker : MonoBehaviour {
	public int numEnemies = 0;
	private int enemiesRemaining = 0;
	
	public int numCollectibles = 0;
	private int collectiblesRemaining = 0;
	
	public int numNoms = 0;
	private int nomsRemaining = 0;
	
	public int numSecrets = 0;
	private int secretsRemaining = 0;
	
	// Use this for initialization
	void Start () {
		enemiesRemaining = numEnemies;
		collectiblesRemaining = numCollectibles;
		nomsRemaining = numNoms;
		secretsRemaining = numSecrets;
	}
	
	// Update is called once per frame
	void Update () {
	}
	
	public int GetNumSecrets() {
		return numSecrets;
	}
	
	public void DecreaseSecretCount() {
		secretsRemaining--;
	}
	
	public int GetRemainingSecrets() {
		return secretsRemaining;
	}
	
	public int GetSecretsCollected() {
		return numSecrets - secretsRemaining;
	}
	
	public void DecreaseNomCount() {
		nomsRemaining--;
	}
	
	public int GetRemainingNoms() {
		return nomsRemaining;
	}
	
	public int GetNomsEaten() {
		return numNoms - nomsRemaining;
	}
	
	public void DecreaseEnemyCount() {
		enemiesRemaining--;
	}
	
	public int GetRemainingEnemies() {
		return enemiesRemaining;
	}
	
	public int GetNumEnemies() {
		return numEnemies;
	}
	
	public int GetEnemiesDefeated() {
		return numEnemies - enemiesRemaining;
	}
	
	public void DecreaseCollectibleCount() {
		collectiblesRemaining--;
	}
	
	public int GetRemainingCollectibles() {
		return collectiblesRemaining;
	}
	
	public int GetNumCollectibles() {
		return numCollectibles;
	}
	
	public int GetCollectiblesCollected() {
		return numCollectibles - collectiblesRemaining;
	}
}

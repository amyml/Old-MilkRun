using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FarseerPhysics.Collision.Shapes;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptFinish : MonoBehaviour {

	//script Master!!
	private scriptGlobalInformation scriptGlobalInformation;	
	private scriptMaster scriptMaster;	
	private scriptHealth scriptHealth;	
	private scriptGuiTimer scriptGuiTimer;	
	private scriptStatTracker scriptStatTracker;	
	private scriptCameraFollow scriptCameraFollow;	
	private scriptGuiCollectibles scriptGuiCollectibles;	
	private scriptSoundsPlayer scriptSoundsPlayer;
	public GameObject player;
	private GameObject mainCamera;
	public GameObject NutritionFacts;
	public string levelName = "Level 1";
	public string levelToLoad = "Level2";
	public float timeBeforeLevelLoad = 14.0f;
	
	private bool isFinished = false;
	public bool linearCameraVelocity = true;
	public float cameraMoveSpeed = 2.6f;
	public float distanceEpsilonCamera = 0.02f;
	
	private bool scoreSet = false;
	private bool scoreCalculated = false;
	
	public float finalZoom = 1.5f;
	public float zoomSpeed = 2.0f;
	
	private Body body;
	
	private float scoreTimer = 0.0f;
	public float timeBeforeScoreShown = 1.5f;
	
	public int collectibleScoreMultiplier = 10;
	public int averageTimeCompletion = 20;
	public int timeScoreMultiplier = 50;
	public int enemyScoreMultiplier = 100;
	public int healthScoreMultiplier = 10;
	//public int perfectTimeScore = 10;
	
	public int levelUnlockedOnFinish = 1;
	
	public int secsForGradeA = 15;
	public int secsForGradeB = 30;
	public int secsForGradeC = 50;
	public int secsForGradeD = 150;
	
	private bool showingScore = false;
	
	void Start()
	{
		//NutritionFacts = GameObject.Find("prefabPlayer/NutritionFacts");
		mainCamera = GameObject.Find("Main Camera");
		scriptMaster = (scriptMaster)(GameObject.Find("Main Camera").GetComponent("scriptMaster"));		
		scriptCameraFollow = GameObject.Find("Main Camera").GetComponent<scriptCameraFollow>();
		scriptHealth = (scriptHealth)(player.GetComponent("scriptHealth"));
		scriptGuiTimer = (scriptGuiTimer)(player.GetComponent("scriptGuiTimer"));	
		scriptGuiCollectibles = (scriptGuiCollectibles)(player.GetComponent("scriptGuiCollectibles"));
		scriptSoundsPlayer = (scriptSoundsPlayer)(GameObject.Find("Sounds").GetComponent("scriptSoundsPlayer"));
		
		GameObject gi = GameObject.Find("GlobalInformation");
		scriptGlobalInformation = null;
		if(gi)
			scriptGlobalInformation = (scriptGlobalInformation)(gi.GetComponent("scriptGlobalInformation"));
			
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.IsSensor = true;
		body.OnCollision += OnCollisionEvent;
		
		isFinished = false;
		showingScore = false;
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		//If Mr. Milk crosses the finish line, the level is completed
		
		ScriptCharCollisions charCollisions = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<ScriptCharCollisions>();
		//scriptGuiTimer = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptGuiTimer>();
		if (charCollisions != null)
		{
			charCollisions.Finish();
			StartCoroutine (LoadLevelAfterDelay(levelToLoad, timeBeforeLevelLoad));
			scriptGuiTimer.EndTimer();
			scriptGuiCollectibles.EndDisplay();
			
			//mainCamera.SendMessage("DisableScript");
			scriptCameraFollow.Disable();
			scriptMaster.DisableCharacterControl();
			isFinished = true;
		}
		
		return true;
	}
	
	public void Update() {
	
		if(isFinished) {
			FinishSequence(player.transform.position);
			
			if(showingScore)
			{
				if(Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return))
				{
					//Skip score screen
					Application.LoadLevel(levelToLoad);
				}	
			}
		}
	}
	
	private void FinishSequence(Vector3 playerPosition) {
		if((scoreTimer += Time.deltaTime) >= timeBeforeScoreShown && !scoreSet)
		{
			SetScore();
		}
		MoveCameraToPlayer(playerPosition);
		
		if(!scoreCalculated)
		{
			scriptSoundsPlayer.PlaySoundWithDelay(scriptSoundsPlayer.PLAYERWIN, 0.5f);
			CalculateScores();
		}
	}

	
	private void MoveCameraToPlayer(Vector3 playerPosition) {
		//Zoom
		if(mainCamera.camera.orthographicSize  - finalZoom > distanceEpsilonCamera) {
			mainCamera.camera.orthographicSize -= Time.deltaTime * zoomSpeed;
		}
		
		//Move camera in space toward parallel of player
		Vector3 targetPosition = playerPosition;
		targetPosition.z = mainCamera.transform.position.z;
		Vector3 direction = targetPosition - mainCamera.transform.position;
		float distance = direction.magnitude;
		if(distance < distanceEpsilonCamera) {
			showingScore = true;
		}
		else {
			if(linearCameraVelocity)
				direction.Normalize();
			mainCamera.transform.position += direction * Time.deltaTime * cameraMoveSpeed;
		}
	}
	
	
	//Values for calculating
	private int numCollectibles = 0;
	private int collectiblesCollected = 0;
	private int numEnemies = 0;
	private int enemiesDefeated = 0;
	private int secsRemaining = 0;
	private int healthRemaining = 0;
	private string timeString = "";
	
	private int collectibleBonus = 0;
	private int healthBonus = 0;
	private int timeBonus = 0; //Dont let it go negative
	private int enemyBonus = 0;
	private int totalBonus = 0;
	//Perfect health + average time + all enemies
	private int perfectScore = 0;
	private int totalScore = 0;
	private int nomsEaten = 0;
	
	private int numSecrets = 0;
	private int secretsCollected = 0;
	
	private string milkGrade = "A";
	
	private void CalculateScores() {
		scriptStatTracker = (scriptStatTracker)(GameObject.Find("prefabStatTracker").GetComponent("scriptStatTracker"));
		
		numSecrets = scriptStatTracker.GetNumSecrets();
		secretsCollected = scriptStatTracker.GetSecretsCollected();
		
		numCollectibles = scriptStatTracker.GetNumEnemies();
		collectiblesCollected = scriptStatTracker.GetCollectiblesCollected();
		nomsEaten = scriptStatTracker.GetNomsEaten();
		
		numEnemies = scriptStatTracker.GetNumEnemies();
		enemiesDefeated = scriptStatTracker.GetEnemiesDefeated();
		secsRemaining = (int)scriptGuiTimer.GetSeconds();
		healthRemaining = (int)scriptHealth.GetCurrHealth();
		timeString = scriptGuiTimer.GetTimeString();
		
		collectibleBonus = collectiblesCollected * collectibleScoreMultiplier;
		healthBonus = healthRemaining * healthScoreMultiplier;
		timeBonus = (averageTimeCompletion - secsRemaining) * timeScoreMultiplier > 0 ? (averageTimeCompletion - secsRemaining) * timeScoreMultiplier : 0; //Dont let it go negative
		enemyBonus = enemyScoreMultiplier * enemiesDefeated;
		totalBonus = healthBonus + timeBonus + enemyBonus + collectibleBonus;
		
		//Perfect health + all enemies
		perfectScore = (collectibleScoreMultiplier*numCollectibles) + (100 * healthScoreMultiplier)
						+ timeBonus + (enemyScoreMultiplier*numEnemies);
		totalScore = (totalBonus * 100) / (perfectScore);
		
		if(secsRemaining < secsForGradeA)
		{
			milkGrade = "A";
		}
		else if(secsRemaining < secsForGradeB)
		{
			milkGrade = "B";
		}
		else if(secsRemaining < secsForGradeC)
		{
			milkGrade = "C";
		}
		else if(secsRemaining < secsForGradeD)
		{
			milkGrade = "Yogurt";
		}
		else
		{
			milkGrade = "Cheese";
		}
		
		
		scoreCalculated = true;
		
		if(scriptGlobalInformation)
			AddToAchievements();
	}
	
	private void AddToAchievements() {
		scriptGlobalInformation.totalCoinsCollected += collectiblesCollected;
		scriptGlobalInformation.totalNomsEaten += nomsEaten;
		scriptGlobalInformation.totalEnemiesDefeated += enemiesDefeated;
		if(scriptGlobalInformation.levelUnlocked < levelUnlockedOnFinish) {
			scriptGlobalInformation.levelUnlocked = levelUnlockedOnFinish;
		}
	}
	
	private void SetScore() {
		NutritionFacts.gameObject.SetActive(true);

		GameObject.Find("TitleLevelValues").GetComponent<TextMesh>().text = "% " + levelName + " Values*";
		GameObject.Find("CollectibleScore").GetComponent<TextMesh>().text += "  " + collectiblesCollected;
		GameObject.Find("TimeScore").GetComponent<TextMesh>().text += "  " + timeString;
		GameObject.Find("EnemyScore").GetComponent<TextMesh>().text += "  " + enemiesDefeated + "/" + numEnemies;;
		
		GameObject.Find("TotalBonus").GetComponent<TextMesh>().text += "  " + totalBonus;
		GameObject.Find("HealthBonus").GetComponent<TextMesh>().text += "  " + healthBonus;
		GameObject.Find("EnemyBonus").GetComponent<TextMesh>().text += "  " + enemyBonus;
		GameObject.Find("TimeBonus").GetComponent<TextMesh>().text += "  " + timeBonus;
		GameObject.Find("CollectibleBonus").GetComponent<TextMesh>().text += "  " + collectibleBonus;
		GameObject.Find("TotalScore").GetComponent<TextMesh>().text += "  " + totalScore + "%";
		
		GameObject.Find("GradeScore").GetComponent<TextMesh>().text = milkGrade;
		
		GameObject.Find("SecretsFound").GetComponent<TextMesh>().text = "Secrets Found  " + secretsCollected + "/?";

		scoreSet= true;
	}
	
	private IEnumerator LoadLevelAfterDelay(string nextLevel, float delay)
	{
		yield return new WaitForSeconds(delay);
		
		Application.LoadLevel(nextLevel);	
	}
}

//ScriptCharCollisions.cs holds timing in LevelEnd() function
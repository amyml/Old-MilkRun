using UnityEngine;
using System.Collections;

public class scriptMusicFollow : MonoBehaviour {

	/*
	 * This script is for making the Music GameObject follow the 
	 * Main Camera along the X and Y axis.
	 */
	
	public GameObject camera;
	
	
	void Start ()
	{
		
	}
	
	void Update () 
	{
		this.transform.position = camera.transform.position;
	}
}

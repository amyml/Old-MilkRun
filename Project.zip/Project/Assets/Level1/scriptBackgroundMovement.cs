using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class scriptBackgroundMovement : MonoBehaviour {

	public Transform camera;
	public float initialX = 0;
	public GameObject[] backgroundPlanes;
	public float[] speedWithPlayer;

	// Use this for initialization
	void Start () {
		initialX = 0;
		for(int i = 0; i < backgroundPlanes.Length; i++)
		{
			Vector3 trans = backgroundPlanes[i].transform.position; // copy to an auxiliary variable...
			trans.x = initialX; // modify the component you want in the variable...
			backgroundPlanes[i].transform.position = trans; 
		}
		//if(backgroundPlanes.Length != speedWithPlayer.Length)
			
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 transf = camera.transform.position;
		float distance = transf.x - initialX; // positive is to the right
		for(int i = 0; i < backgroundPlanes.Length; i++)
		{
			Vector3 trans = backgroundPlanes[i].transform.position; // copy to an auxiliary variable...
			trans.x = distance * speedWithPlayer[i]; // modify the component you want in the variable...
			backgroundPlanes[i].transform.position = trans;
		}
	}
	
}

/*
 * This script is for making the Main Camera follow the 
 * player along the X axis, and sizing up when the player
 * moves too high vertically.
 */

public var mainPlayer 					: GameObject;
public var cameraLeftLimit				: float = -2;
public var cameraRightLimit				: float = 110;
public var cameraDefaultY 				: float = 2;
public var cameraDefaultZ 				: float = -70;
public var cameraDefaultSize			: float = 3;
public var verticalMovementThreshold 	: float = 4;
public var cameraExpandAmount			: float = 0.4;
public var cameraClimbAmount			: float = 0.5;

private var currSize 					: float;


function Start ()
{
	currSize = cameraDefaultSize;
	this.camera.orthographicSize = cameraDefaultSize;
}

function Update () 
{
	var cameraTransform = this.gameObject.transform;
	var playerTransform = mainPlayer.gameObject.transform;
	
	var newCameraY = cameraDefaultY;

	//Check the players y-coordinate and scale up camera if above threshold
	if(playerTransform.position.y <= verticalMovementThreshold)
	{
		this.camera.orthographicSize = cameraDefaultSize;
	}
	else //Over the threshold, update size and y-position
	{
		this.camera.orthographicSize = cameraDefaultSize + cameraExpandAmount*(playerTransform.position.y - verticalMovementThreshold);
		newCameraY += cameraClimbAmount*(playerTransform.position.y - verticalMovementThreshold);
	}
	
	
	//Follow the player's x-position
	var playerX : float = playerTransform.position.x;
	if(playerX > cameraLeftLimit && playerX < cameraRightLimit)
		cameraTransform.position = new Vector3(playerX, newCameraY, cameraDefaultZ);
	else if(playerX <= cameraLeftLimit)
		cameraTransform.position = new Vector3(cameraLeftLimit, newCameraY, cameraDefaultZ);
	else if(playerX >= cameraRightLimit)
		cameraTransform.position = new Vector3(cameraRightLimit, newCameraY, cameraDefaultZ);
	
}

function DisableScript() {
	this.enabled = false;
}
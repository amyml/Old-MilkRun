using UnityEngine;
using System.Collections;

public class scriptPauseGame : MonoBehaviour {
	
	//Inspector Variables
	public float buttonSize 		 = 200.0f;
	public string mainMenuToLoad;
	public string pauseKeyID		 = "escape";
	
    public Texture2D resumeButton = null;
	public Texture2D restartButton = null;
	public Texture2D mainMenuButton = null;
	public Texture2D quitButton = null;
	public Texture2D grayBackground = null;
	
	//Private Variables
	private bool isPaused 			 = false;
	
	//the master game script
	private scriptMaster scriptMaster;
	
	public float buttonWidth = 400.0f;
	public float buttonHeight = 100.0f;
	
	private int chosenButton = 0;
	
	private scriptSoundsPlayer scriptSoundsPlayer;
	private float musicFadeInTime = 0.015f;

	void Start () {
		scriptMaster = (scriptMaster)(GameObject.Find("Main Camera").GetComponent("scriptMaster"));
		
		resumeButtonWidth = buttonWidth;
		resumeButtonHeight = buttonHeight;
		restartButtonWidth = buttonWidth;
		restartButtonHeight = buttonHeight;
		mainMenuButtonWidth = buttonWidth;
		mainMenuButtonHeight = buttonHeight;
		quitButtonWidth = buttonWidth;
		quitButtonHeight = buttonHeight;
		
		scriptSoundsPlayer = (scriptSoundsPlayer)(GameObject.Find("Sounds").GetComponent("scriptSoundsPlayer"));
	}
	

	void Update () {
	   if(Input.GetKeyDown(pauseKeyID) && !isPaused)
	   {
		  scriptSoundsPlayer.setVolumeTo(scriptSoundsPlayer.LEVELMUSIC, 0.2f);
	      Time.timeScale = 0.0f;
	      isPaused = true;
	      scriptMaster.DisableCharacterControl();
		  chosenButton = 0;
			
		  SetButtonDimensions();
	   }
	   else if(Input.GetKeyDown(pauseKeyID) && isPaused)
	   {
		  scriptSoundsPlayer.FadeInSound(scriptSoundsPlayer.LEVELMUSIC, 0.7f, musicFadeInTime);
	      Time.timeScale = 1.0f;
	      isPaused = false; 
	      scriptMaster.EnableCharacterControl();   
	   }
		
		if(Input.GetKeyDown(KeyCode.UpArrow))
		{
			if(chosenButton > 0) {
				chosenButton--;
			
				SetButtonDimensions();
				scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.MENUSELECT);
			}
		}
		
		if(Input.GetKeyDown(KeyCode.DownArrow))
		{
			if(chosenButton < 3) {
				chosenButton++;
			
				SetButtonDimensions();
				scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.MENUSELECT);
			}
		}
		
		if(isPaused && (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return)))
		{
			ChooseButton();
		}

	}
	
	private float resumeButtonWidth = 0.0f;
	private float resumeButtonHeight = 0.0f;
	private float restartButtonWidth = 0.0f;
	private float restartButtonHeight = 0.0f;
	private float mainMenuButtonWidth = 0.0f;
	private float mainMenuButtonHeight = 0.0f;
	private float quitButtonWidth = 0.0f;
	private float quitButtonHeight = 0.0f;
	
	private float chosenSize = 1.1f;
	
	private float guiButtonSize = 0.85f;
	
	private void SetButtonDimensions() {
		resumeButtonWidth = buttonWidth;	
		resumeButtonHeight = buttonHeight;
		restartButtonWidth = buttonWidth;	
		restartButtonHeight = buttonHeight;
		mainMenuButtonWidth = buttonWidth;	
		mainMenuButtonHeight = buttonHeight;
		quitButtonWidth = buttonWidth;	
		quitButtonHeight = buttonHeight;
		
		if(chosenButton == 0)
		{
			resumeButtonWidth = buttonWidth * chosenSize;	
			resumeButtonHeight = buttonHeight * chosenSize;
		}
		else if(chosenButton == 1)
		{
			restartButtonWidth = buttonWidth * chosenSize;	
			restartButtonHeight = buttonHeight * chosenSize;
		}
		else if(chosenButton == 2)
		{
			mainMenuButtonWidth = buttonWidth * chosenSize;	
			mainMenuButtonHeight = buttonHeight * chosenSize;
		}
		else
		{
			quitButtonWidth = buttonWidth * chosenSize;	
			quitButtonHeight = buttonHeight * chosenSize;
		}
	}
	
	private void ChooseButton() {
		if(chosenButton == 0)
		{
        	Time.timeScale = 1.0f;
        	isPaused = false;
        	scriptMaster.EnableCharacterControl();  
			scriptSoundsPlayer.FadeInSound(scriptSoundsPlayer.LEVELMUSIC, 0.7f, musicFadeInTime);
		}
		else if(chosenButton == 1)
		{
			Application.LoadLevel(Application.loadedLevel);
			Time.timeScale = 1.0f;
         	isPaused = false;  
         	scriptMaster.EnableCharacterControl(); 
		}
		else if(chosenButton == 2)
		{
			Application.LoadLevel(mainMenuToLoad);
			Time.timeScale = 1.0f;
         	isPaused = false;  
         	scriptMaster.EnableCharacterControl(); 
		}
		else
		{
			Application.Quit();
			Time.timeScale = 1.0f;
         	isPaused = false;   
         	scriptMaster.EnableCharacterControl(); 
		}
	}
	
	void OnGUI()
	{
		if(isPaused)
		{
			/*
			if(GUI.Button(new Rect(Screen.width/2 - resumeButtonWidth*guiButtonSize/2, 100, resumeButtonWidth*guiButtonSize, resumeButtonHeight), "Resume"))
			{
	        	Time.timeScale = 1.0f;
	        	isPaused = false;
	        	scriptMaster.EnableCharacterControl();  
				scriptSoundsPlayer.FadeInSound(scriptSoundsPlayer.LEVELMUSIC, 0.7f, musicFadeInTime);
			}
			if(GUI.Button(new Rect(Screen.width/2 - restartButtonWidth*guiButtonSize/2, 220, restartButtonWidth*guiButtonSize, restartButtonHeight), "Restart"))
			{
				Application.LoadLevel(Application.loadedLevel);
				Time.timeScale = 1.0f;
	         	isPaused = false;  
	         	scriptMaster.EnableCharacterControl(); 
			}
			if(GUI.Button(new Rect(Screen.width/2 - mainMenuButtonWidth*guiButtonSize/2, 340, mainMenuButtonWidth*guiButtonSize, mainMenuButtonHeight), "Main Menu"))
			{
				Application.LoadLevel(mainMenuToLoad);
				Time.timeScale = 1.0f;
	         	isPaused = false;  
	         	scriptMaster.EnableCharacterControl(); 
			}
			if(GUI.Button(new Rect(Screen.width/2 - quitButtonWidth*guiButtonSize/2, 460, quitButtonWidth*guiButtonSize, quitButtonHeight), "Quit"))
			{
				Application.Quit();
				Time.timeScale = 1.0f;
	         	isPaused = false;   
	         	scriptMaster.EnableCharacterControl(); 
			}
			*/
			
			//Draw the picture buttons
			GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), grayBackground);
			
			GUI.DrawTexture(new Rect(Screen.width/2 - resumeButtonWidth/2, 50, resumeButtonWidth, resumeButtonHeight), resumeButton);
			
			GUI.DrawTexture(new Rect(Screen.width/2 - restartButtonWidth/2, 130, restartButtonWidth, restartButtonHeight), restartButton);
			
			GUI.DrawTexture(new Rect(Screen.width/2 - mainMenuButtonWidth/2, 210, mainMenuButtonWidth, mainMenuButtonHeight), mainMenuButton);
			
			GUI.DrawTexture(new Rect(Screen.width/2 - quitButtonWidth/2, 290, quitButtonWidth, quitButtonHeight), quitButton);
			
			/*
			if(GUI.Button(new Rect(Screen.width/2 - buttonWidth/2, 100, buttonWidth, buttonHeight), "Resume"))
			{
	        	Time.timeScale = 1.0f;
	        	isPaused = false;
	        	scriptMaster.EnableCharacterControl();  
			}
			*/
			/*
			if
			(GUI.Button(new Rect(Screen.width/3, 70, buttonSize, 50), "Restart"))
			{
				Application.LoadLevel(Application.loadedLevel);
				Time.timeScale = 1.0f;
	         	isPaused = false;  
	         	scriptMaster.EnableCharacterControl(); 
			}
			if(GUI.Button(new Rect(Screen.width/3, 130, buttonSize, 50), "Main Menu"))
			{
				Application.LoadLevel(mainMenuToLoad);
				Time.timeScale = 1.0f;
	         	isPaused = false;  
	         	scriptMaster.EnableCharacterControl(); 
			}
			if(GUI.Button(new Rect(Screen.width/3, 190, buttonSize, 50), "Quit"))
			{
				Application.Quit();
				Time.timeScale = 1.0f;
	         	isPaused = false;   
	         	scriptMaster.EnableCharacterControl(); 
			}
			*/
		}
	}
}

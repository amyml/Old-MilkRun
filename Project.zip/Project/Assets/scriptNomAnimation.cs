using UnityEngine;
using System.Collections;

public class scriptNomAnimation : MonoBehaviour {
	
	// Animations
    private Renderer moveRenderer;
    private OTAnimatingSprite moveSprite;
	private Renderer noticeRenderer;
    private OTAnimatingSprite noticeSprite;
	private Renderer idleRenderer;
    private OTAnimatingSprite idleSprite;
	
	private Component[] sprites;
	
	//Directions
    private int currFacingDir = 1;
	private int lastFacingDir = 2;
	
	//Mobility
	private bool movable;
	
	//Nom Type
	private float nomType;
	// 0f = chocolate
	// 1f = strawberry
	
	private int LEFT = 1;
	//private int RIGHT = 2;
	
	//Scripts
	private scriptNomController nomScript;
	
	
	
	
	// Use this for initialization
	void Start () {
		
		//Scripts		
		nomScript = gameObject.GetComponent<scriptNomController>();
		
		//Alive and movable
		movable = true;
		
		//Sprites & Rendering Sprites
		sprites = GetComponentsInChildren<OTAnimatingSprite>();
		
		if (this.tag == "ChocolateNom"){
			nomType = 0f;
		}
		else if (this.tag == "StrawberryNom"){
			nomType = 1f;
		}
		
		foreach (OTAnimatingSprite s in sprites){
			if(s.tag == "NomMove")
				moveSprite = s;
			else if(s.tag == "NomNotice")
				noticeSprite = s;
			else if(s.tag == "NomIdle")
				idleSprite = s;
		}
		
		moveRenderer = moveSprite.renderer;    	
    	moveRenderer.enabled = true;
		
		noticeRenderer = noticeSprite.renderer;    	
    	noticeRenderer.enabled = false;
		
		idleRenderer = idleSprite.renderer;    	
    	idleRenderer.enabled = false;

		moveSprite.transform.localScale = new Vector3(1.5f, 1.5f, 1f);
		idleSprite.transform.localScale = new Vector3(1.5f, 1.5f, 1f);
		noticeSprite.transform.localScale = new Vector3(1.5f, 1.5f, 1f);
		noticeSprite.transform.renderer.material.mainTextureScale = new Vector3(0.5f, 0.5f, 1f);
		if (nomType == 1f)
		{
			moveSprite.transform.renderer.material.mainTextureScale = new Vector3(0.5f, 0.5f, 1f);
			idleSprite.transform.renderer.material.mainTextureScale = new Vector3(0.5f, 0.5f, 1f);
		}
	}
	
	// Update is called once per frame
	void Update () {
		
		//Directions
		currFacingDir = nomScript.GetDirection();
		
		if(true)
		{
			if(nomScript.GetDirection() == LEFT)
			{
				//facing left
				moveSprite.transform.localScale = new Vector3(1.5f, 1.5f, 1f);
				idleSprite.transform.localScale = new Vector3(1.5f, 1.5f, 1f);
				noticeSprite.transform.localScale = new Vector3(1.5f, 1.5f, 1f);
				noticeSprite.transform.renderer.material.mainTextureScale = new Vector3(0.5f, 0.5f, 1f);
				if (nomType == 1f)
				{
					moveSprite.transform.renderer.material.mainTextureScale = new Vector3(0.5f, 0.5f, 1f);
					idleSprite.transform.renderer.material.mainTextureScale = new Vector3(0.5f, 0.5f, 1f);
				}
			}
			else
			{
				//facing right
				moveSprite.transform.localScale = new Vector3(-1.5f, 1.5f, 1f);
				idleSprite.transform.localScale = new Vector3(-1.5f, 1.5f, 1f);
				noticeSprite.transform.localScale = new Vector3(-1.5f, 1.5f, 1f);
				noticeSprite.transform.renderer.material.mainTextureScale = new Vector3(-0.5f, 0.5f, 1f);
				if (nomType == 1f)
				{
					moveSprite.transform.renderer.material.mainTextureScale = new Vector3(-0.5f, 0.5f, 1f);
					idleSprite.transform.renderer.material.mainTextureScale = new Vector3(-0.5f, 0.5f, 1f);
				}
			}
			
		}
		
		//Update direction
		lastFacingDir = currFacingDir;
		
		if (movable)
		{
			/*
			 * if (!IsEscaping() && !IsMoving())
			 * {
			 * //Nom is idle
			 * idleRenderer.enabled = true;
			 * noticeRenderer.enabled = false;
			 * moveRenderer.enabled = false;
			 *
			 * idleSprite.animation.fps = 8f;
			 * idleSprite.animation.duration = 0.5f;
			 *
			 * if(!idleSprite.isPlaying)
	       	 *  	idleSprite.Play(");
			 * }
			 */
				
			//Nom is moving
			moveRenderer.enabled = true;
			noticeRenderer.enabled = false;
			idleRenderer.enabled = false;
				
			moveSprite.animation.fps = 8f;
			moveSprite.animation.duration = 0.5f;
			
			//Tiling issue demands that offset be manually set
			if (nomType == 1f)
				moveSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.5f);
				
			if(!moveSprite.isPlaying)
	       	   	moveSprite.Play("move");
				
		}		
	
	}
	
	//Called by ScriptNomController when nom notices player
	public void Notice()
	{
		
		moveRenderer.enabled = false;
		idleRenderer.enabled = false;
		noticeRenderer.enabled = true;
		
		noticeSprite.animation.fps = 2f;
		noticeSprite.animation.duration = 0.25f;
		
		//Tiling issue demands that offset be manually set
		noticeSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.5f);
				
		if(!noticeSprite.isPlaying)
	       	   noticeSprite.Play();
		
		StartCoroutine(FreakOut ());
		
	}
	
	public void ExtendedNotice()
	{
		moveRenderer.enabled = false;
		idleRenderer.enabled = false;
		noticeRenderer.enabled = true;
		
		noticeSprite.animation.fps = 2f;
		noticeSprite.animation.duration = 0.25f;
		
		//Tiling issue demands that offset be manually set
		noticeSprite.transform.renderer.material.mainTextureOffset = new Vector2(0f, 0.5f);
				
		if(!noticeSprite.isPlaying)
	       	   noticeSprite.Play();
		
		movable = false;
	}
	
	public void Unnotice()
	{
		movable = true;
		noticeRenderer.enabled = false;
		moveRenderer.enabled = true;
	}
	
	//Stalls normal animation for nom to notice player
	private IEnumerator FreakOut()
	{
		movable = false;
		
		//Allow time for animation
		yield return new WaitForSeconds(1f);
		
		movable = true;
		noticeRenderer.enabled = false;
		moveRenderer.enabled = true;
	}
	
	// Returns type of nom
	// 0f for chocolate, 1f for strawberry
	public float GetType()
	{
		return nomType;
	}
}

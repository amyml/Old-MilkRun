using UnityEngine;
using System.Collections;
using FVector2 = Microsoft.Xna.Framework.FVector2;


public class scriptDebugOutput : MonoBehaviour {
	
	//script Master!!
	private scriptMaster scriptMaster;
	
	private GameObject player;
	private scriptHealth playerHealth;
	private ScriptCharCollisions playerPhysics;
	
	// Use this for initialization
	void Start () {
		scriptMaster = (scriptMaster)(GameObject.Find("Main Camera").GetComponent("scriptMaster"));	
		player = GameObject.FindGameObjectWithTag("MrMilk");
		if(player != null)
		{
			playerHealth = player.GetComponent<scriptHealth>();
			playerPhysics = player.GetComponent<ScriptCharCollisions>();
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	
	private void OnGUI()
	{
		if(scriptMaster.DebugMode())
		{
			GUI.color = new Color(1.0f, 0.0f, 0.0f, 1.0f);
			GUI.Label(new Rect(100,60,100,70), "Health: " + (playerHealth.GetCurrHealth()));
			GUI.Label(new Rect(100,70,100,70), "Player Velocity: " + playerPhysics.GetVelocity().ToString());

				
		}
	}
}

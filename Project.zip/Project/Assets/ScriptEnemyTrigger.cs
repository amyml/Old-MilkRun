using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;

public class ScriptEnemyTrigger : MonoBehaviour {
	
	private Body body;
	
	private bool activate = false;
	
	private ScriptTriggerTrap triggerTrap;
	
	// Use this for initialization
	void Start () {
		body = gameObject.GetComponent<FSBodyComponent>().PhysicsBody;
		//body.IsSensor = true;
		
		triggerTrap = gameObject.transform.parent.GetComponent<ScriptTriggerTrap>();
		
		body.OnCollision += OnCollisionEvent;
		
	}
	
	// Update is called once per frame
	void Update () {
	
		if(activate)
		{
			triggerTrap.SetActive();	
			activate = false;
		}
		
	}
	
	private bool OnCollisionEvent(Fixture FixtureA, Fixture FixtureB, Contact contact)
	{
		scriptHealth enemy = FixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptHealth>();
		
		if(enemy != null && enemy.GetTeam() == 1)
		{
			activate = true;
		}
		
		if( FixtureB.Body.IsStatic)
		{
			return true;	
		}
		
		return false;
	}

}

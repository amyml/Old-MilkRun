using UnityEngine;
using System.Collections;

using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class scriptMovingPlatform : MonoBehaviour {
	
	public enum Movement { Vertical = 0, Horizontal = 1 }
	public Movement movement = Movement.Vertical;
	public float minPosition = 2.0f;
	public float maxPosition = 5.2f;
	
	public float movementSpeed = 0.8f;
	private bool up = true;
	private bool right = true;
	
	private bool holdingPlayer = false;
	
	private Body body;
	private Body playerBody;
	private GameObject player;

	void Start () {
		if(movement == Movement.Vertical)
		{
			this.transform.position = new Vector3(transform.position.x, minPosition, transform.position.z);
			up = true;
		}
		else //movement == Movement.Horizontal
		{
			this.transform.position = new Vector3(minPosition, transform.position.y, transform.position.z);
			right = true;
		}
		
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		//body.OnCollision += OnCollisionEvent;
		//body.OnSeparation += OnSeparationEvent;
		
		//player = GameObject.FindGameObjectWithTag("MrMilk");
		//playerBody = player.GetComponent<FSBodyComponent>().PhysicsBody;
	}

	void Update () {
		if(movement == Movement.Vertical)
		{
			if(up)
			{
				body.LinearVelocity = new FVector2(0, movementSpeed);
				if(this.transform.position.y >= maxPosition)
					up = false;
			}
			else // down
			{
				body.LinearVelocity = new FVector2(0, -1*movementSpeed);
				if(this.transform.position.y <= minPosition)
					up = true;
			}
		}
		else //movement == Movement.Horizontal
		{
			if(right)
			{
				body.LinearVelocity = new FVector2(movementSpeed, 0);
				if(this.transform.position.x >= maxPosition)
					right = false;
				
			}
			else // down
			{
				body.LinearVelocity = new FVector2(-1 * movementSpeed, 0);
				if(this.transform.position.x <= minPosition)
					right = true;
			}
		}
	}
	
	/*
	private void OnSeparationEvent(Fixture fixtureA, Fixture fixtureB)
	{
		holdingPlayer = false;
	}
		
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		//A = you
		//B = them
		if(fixtureB.Body.UserFSBodyComponent.gameObject.tag == "MrMilk")
		{	
			holdingPlayer = true;
		}
		
		return true;
	}
	*/
}

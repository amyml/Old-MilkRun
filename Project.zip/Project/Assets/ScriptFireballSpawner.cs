using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class ScriptFireballSpawner : MonoBehaviour {
	
	public int maxObjects = 10;
	
	public float delay = 0.2f;
			
	public GameObject fireball;
	
	
	private float coolTimer = -1.0f;
	public int spawnCount = 0;
	
	
	// Use this for initialization
	void Start () {
	
		
		
	}
	
	// Update is called once per frame
	void Update () {
		if(spawnCount < maxObjects)
		{
			coolTimer -= Time.deltaTime;
	
			if(coolTimer <= 0.0f)
			{
				SpawnObject();
				coolTimer = delay;
				spawnCount++;
			}
		}
	}
	
	public void SpawnObject()
	{
		float randX = Random.value;
		float randY = Random.value;
		
		GameObject firedObject = (GameObject) GameObject.Instantiate(fireball, gameObject.transform.position, gameObject.transform.rotation);
	
		Body objBody = firedObject.GetComponent<FSBodyComponent>().PhysicsBody;
		
		
		objBody.LinearVelocity = new FVector2(randX, randY);
		
		ScriptProjectile fireProj = firedObject.GetComponent<ScriptProjectile>();
		fireProj.SetTeam(0);
		
	}
}

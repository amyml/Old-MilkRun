using UnityEngine;
using System.Collections;

public class scriptAnimation : MonoBehaviour {
	
	//Animation
	private Renderer runRenderer;
    private OTAnimatingSprite runSprite;
	private Renderer travelRenderer;
    private OTAnimatingSprite travelSprite;
	
	//Directions
    private int currFacingDir = 2;
	private int lastFacingDir = 1;
	
	private int LEFT = 1;
	
	private bool traveling = false;

	// Use this for initialization
	void Start () {
		runRenderer = GameObject.Find("playerRun").renderer;
    	runSprite = GameObject.Find("playerRun").GetComponent<OTAnimatingSprite>();
		runRenderer.enabled = true;
		
		travelRenderer = GameObject.Find("playerTravel").renderer;
    	travelSprite = GameObject.Find("playerTravel").GetComponent<OTAnimatingSprite>();
		travelRenderer.enabled = false;
	}
	
	// Update is called once per frame
	void Update () {
		
		//Directions
		if(Input.GetKey(KeyCode.LeftArrow)) 
		{
            //Facing left
            currFacingDir = 1;
			traveling = true;
		}
		else if (Input.GetKey(KeyCode.RightArrow))
		{
			currFacingDir = 2;
			traveling = true;
		}
		else
		{
			traveling = false;	
		}
		
		if(currFacingDir != lastFacingDir)
		{
			
			if(currFacingDir == LEFT)
			{
				//facing left
				runSprite.transform.localScale = new Vector3(-1.25f, 1.25f, 1f);
				travelSprite.transform.localScale = new Vector3(-2.5f, 2.5f, 1f);
			}
			else
			{
				//facing right
				runSprite.transform.localScale = new Vector3(1.25f, 1.25f, 1f);
				travelSprite.transform.localScale = new Vector3(2.5f, 2.5f, 1f);
			}
		}
		
		//Update direction
		lastFacingDir = currFacingDir;
		
		if (traveling)
		{
			travelRenderer.enabled = true;
			runRenderer.enabled = false;
			
			travelSprite.animation.fps = 2f;
			travelSprite.animation.duration = 2f;
			
							
			if(!travelSprite.isPlaying)
				travelSprite.Play();
			
			StartCoroutine(Run ());
		}
		else{
			if(!travelSprite.isPlaying){
				runRenderer.enabled = true;
				travelRenderer.enabled =false;
			}
		}
	}
	
	private IEnumerator Run()
	{	
		traveling = true;
		//Wait for running animation to play
		yield return new WaitForSeconds(3f);
		traveling = false;
		
	}
}

var levelToLoad 	: String;
var soundOnHover	: AudioClip;
var soundOnClick	: AudioClip;
//var isQuitButton 	: boolean = false;
//var isGuiText		: boolean = true;
//var hoveringFontSizeIncr	: int = 0;
var audioMaxVolume 			: float = 1.0;
private var audioVolume 	: float = 1.0;
var audioFadeMultiplier		: float = 0.8;
var selectWaitTimeSecs		: int = 0;
private var isFadingOut		: boolean = false;

function OnMouseEnter(){
	//audio.PlayOneShot(soundOnHover);
	isFadingOut = false;
	audioVolume = audioMaxVolume;
    audio.volume = audioVolume;
	audio.Play();
}

function OnMouseExit()
{
	if(audio.isPlaying)
	{
		isFadingOut = true;
	}
}

function Update()
{
	if(isFadingOut)
		FadeOut();
}

function OnMouseUp(){
	audio.PlayOneShot(soundOnClick);
	yield new WaitForSeconds(selectWaitTimeSecs);
	if(levelToLoad)
	{
		Application.LoadLevel(levelToLoad);
	}
}
@script RequireComponent(AudioSource)

function FadeOut() {
    if(audioVolume > 0.1)
    {
        audioVolume -= audioFadeMultiplier * Time.deltaTime;
        audio.volume = audioVolume;
    }
    else
    {
    	isFadingOut = false;
    }
}
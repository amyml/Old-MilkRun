#pragma strict
//To be attached to the camera

var player 		: GameObject;

var errorSound				: AudioSource;
var cameraDefaultSize		: float = 3;
var cameraDefaultY			: float = 1.014494;
var linearCameraVelocity	: boolean = false;
var cameraMoveSpeed 		: float = 1;
var linearPlayerVelocity	: boolean = false;
var playerMoveSpeed 		: float = 1;

var distanceEpsilonCamera			: float = 0.001;
var distanceEpsilonPlayer			: float = 0.001;

private var cameraZ			: float;
private var playerZ			: float;


var currentWaypointIndex	: int = 0;
var waypoints				: GameObject[];

var lastBreadWaypoint		: int = 0;
var lastFruitWaypoint		: int = 1;

var mainMenuSceneName		: String = "sceneMainMenu";
var breadLevelSceneName		: String = "Level1";
var fruitLevelSceneName		: String = "Level2";
var poultryLevelSceneName	: String = "Level3";

private var reachedCurrentWaypoint : boolean = true;
private var cameraReachedCurrentWaypoint : boolean = true;

function Start () {
	/*
	// Align all waypoints with player's z plane
	for(var i : int = 0; i < waypoints.length; int++) {
		waypoints[i].transform.position.z = player.transform.position.z;
	}
	*/
	
	this.camera.orthographicSize = 3.5f;//changed from 3 to 3.5
	
	cameraZ = this.transform.position.z;
	playerZ = player.transform.position.z;
	
	var currWaypointPosition : Vector3 = waypoints[currentWaypointIndex].transform.position;
	player.transform.position = currWaypointPosition;
	this.transform.position = Vector3(currWaypointPosition.x , cameraDefaultY , cameraZ);
	//added the 3.85 and 1.25 to make sure the camera stays put for now
}

function SetWaypoint(waypointIndex : int) {
	player.transform.position = waypoints[waypointIndex].transform.position;
}

function Update () {
	this.camera.orthographicSize = cameraDefaultSize;

	if(Input.GetKeyDown(KeyCode.Escape)) 	{
		Application.LoadLevel(mainMenuSceneName);
	}

	if(Input.GetKeyDown(KeyCode.LeftArrow) && currentWaypointIndex > 0) 	{
		currentWaypointIndex--;
		reachedCurrentWaypoint = false;
		cameraReachedCurrentWaypoint = false;
	}
	
	if(Input.GetKeyDown(KeyCode.RightArrow))	{
		if(currentWaypointIndex < waypoints.Length - 1) {  //Continue to next waypoint
			currentWaypointIndex++;
			reachedCurrentWaypoint = false;
			cameraReachedCurrentWaypoint = false;
		}
		else {  //Next waypoint is not accessible/existant
			errorSound.Play();
		}
	}
	
	if(Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space))	{
		/*if(currentWaypointIndex <= lastBreadWaypoint) {  // Within bread level
			Application.LoadLevel(breadLevelSceneName);
		}*/
		if (currentWaypointIndex == lastBreadWaypoint)
		{
			Application.LoadLevel(breadLevelSceneName);
		}
		else if (currentWaypointIndex == lastFruitWaypoint)
		{
			Application.LoadLevel(fruitLevelSceneName);
		}
		else //if (currentWaypointIndex == lastBreadWaypoint)
		{
			Application.LoadLevel(poultryLevelSceneName);
		}
	}
	
	var currWaypointPosition : Vector3 = waypoints[currentWaypointIndex].transform.position;
	currWaypointPosition.z = cameraZ;
	currWaypointPosition.z = playerZ;
		
	// Move to new waypoints
	if(!reachedCurrentWaypoint) {
		
		MovePlayerToWaypoint(currWaypointPosition);
	}
	
	if(!cameraReachedCurrentWaypoint) {
		MoveCameraToWaypoint(currWaypointPosition);
	}
}


function MoveCameraToWaypoint(dest : Vector3) {
	var direction : Vector3 = dest - this.transform.position;
	var distance : float = direction.magnitude;
	if(distance < distanceEpsilonCamera) {
		cameraReachedCurrentWaypoint = true;
	}
	else {
		if(linearCameraVelocity)
			direction.Normalize();
		direction.y = 0;
		direction.z = 0;
		this.transform.position += direction * Time.deltaTime * cameraMoveSpeed;
	}
}


function MovePlayerToWaypoint(dest : Vector3) {
	var direction : Vector3 = dest - player.transform.position;
	var distance : float = direction.magnitude;
	if(distance < distanceEpsilonPlayer) {
		reachedCurrentWaypoint = true;
	}
	else {
		if(linearPlayerVelocity)
			direction.Normalize();
		player.transform.position += direction * Time.deltaTime * playerMoveSpeed;
	}
}

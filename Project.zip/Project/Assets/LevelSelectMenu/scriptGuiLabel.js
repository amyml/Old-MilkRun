
/* var thisSkin : GUISkin;

function OnGUI ()
{
	GUI.skin = thisSkin;

	GUI.color = Color.black;
	var PlayText : String = "Press Space to Play!";
	GUI.Label(Rect(Screen.width-950,570,600,45), PlayText);//GUI.Label(Rect(Screen.width-950,625,300,45), PlayText);
} */
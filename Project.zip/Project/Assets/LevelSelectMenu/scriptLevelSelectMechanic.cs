using UnityEngine;
using System.Collections;

public class scriptLevelSelectMechanic : MonoBehaviour {
	
	private scriptGlobalInformation scriptGlobalInformation;
	public GameObject player ;
	
	public AudioSource errorSound;
	public float cameraDefaultSize		 = 3f;
	public float cameraDefaultY			= 1.014494f;
	public bool linearCameraVelocity	= false;
	public float cameraMoveSpeed 		= 1f;
	public bool linearPlayerVelocity	 = false;
	public float playerMoveSpeed 		 = 1f;
	
	public float distanceEpsilonCamera			 = 0.001f;
	public float distanceEpsilonPlayer			 = 0.001f;
	
	private float cameraZ			 ;
	private float playerZ			 ;
	
	
	public int currentWaypointIndex = 0;
	public GameObject[] waypoints;
	public GameObject[] pathways;
	
	public int lastBreadWaypoint		 = 0;
	public int lastFruitWaypoint		 = 1;
	
	public string mainMenuSceneName		= "sceneMainMenu";
	public string breadLevelSceneName		= "Level1";
	public string fruitLevelSceneName		= "Level2";
	public string poultryLevelSceneName    = "Level3";
	
	private bool reachedCurrentWaypoint  = true;
	private bool cameraReachedCurrentWaypoint  = true;
	
	public int currLevel = 0; //currLevel = 1, means you just beat level 1
	
	public float unlockedAlpha = 1.0f;
	public float lockedAlpha = 0.3f;
	
	
	void Start () {
		GameObject gi = GameObject.Find("GlobalInformation");
		scriptGlobalInformation = null;
		if(gi)
			scriptGlobalInformation = (scriptGlobalInformation)(gi.GetComponent("scriptGlobalInformation"));
		
		if(scriptGlobalInformation) {
			currLevel = scriptGlobalInformation.levelUnlocked;
			currentWaypointIndex = currLevel - 1;
			if(currentWaypointIndex < 0) 
				currentWaypointIndex = 0;
		}
		else
			currLevel = 0;
		
		/*
		// Align all waypoints with player's z plane
		for(var i : int = 0; i < waypoints.length; int++) {
			waypoints[i].transform.position.z = player.transform.position.z;
		}
		*/
		
		this.camera.orthographicSize = 3.5f;//changed from 3 to 3.5
		
		cameraZ = this.transform.position.z;
		playerZ = player.transform.position.z;
		
		Vector3 currWaypointPosition = waypoints[currentWaypointIndex].transform.position;
		player.transform.position = currWaypointPosition;
		this.transform.position = new Vector3(currWaypointPosition.x , cameraDefaultY , cameraZ);
		//added the 3.85 and 1.25 to make sure the camera stays put for now
		
		LightUnlockedPaths();
	}
	
	private void SetWaypoint(int waypointIndex) {
		player.transform.position = waypoints[waypointIndex].transform.position;
	}
	
	void Update () {
		this.camera.orthographicSize = cameraDefaultSize;
	
		if(Input.GetKeyDown(KeyCode.Escape)) 	{
			Application.LoadLevel(mainMenuSceneName);
		}
	
		if(Input.GetKeyDown(KeyCode.LeftArrow) && currentWaypointIndex > 0) 	{
			currentWaypointIndex--;
			reachedCurrentWaypoint = false;
			cameraReachedCurrentWaypoint = false;
		}
		
		if(Input.GetKeyDown(KeyCode.RightArrow) && currentWaypointIndex < currLevel)	{
			if(currentWaypointIndex < waypoints.Length - 1) {  //Continue to next waypoint
				currentWaypointIndex++;
				reachedCurrentWaypoint = false;
				cameraReachedCurrentWaypoint = false;
			}
			else {  //Next waypoint is not accessible/existant
				errorSound.Play();
			}
		}
		
		if(Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space))	{
			/*if(currentWaypointIndex <= lastBreadWaypoint) {  // Within bread level
				Application.LoadLevel(breadLevelSceneName);
			}*/
			if (currentWaypointIndex == lastBreadWaypoint)
			{
				Application.LoadLevel(breadLevelSceneName);
			}
			else if (currentWaypointIndex == lastFruitWaypoint)
			{
				Application.LoadLevel(fruitLevelSceneName);
			}
			else //if (currentWaypointIndex == lastBreadWaypoint)
			{
				Application.LoadLevel(poultryLevelSceneName);
			}
		}
		
		Vector3 currWaypointPosition = waypoints[currentWaypointIndex].transform.position;
		currWaypointPosition.z = cameraZ;
		currWaypointPosition.z = playerZ;
			
		// Move to new waypoints
		if(!reachedCurrentWaypoint) {
			
			MovePlayerToWaypoint(currWaypointPosition);
		}
		
		if(!cameraReachedCurrentWaypoint) {
			MoveCameraToWaypoint(currWaypointPosition);
		}
	}
	
	
	void MoveCameraToWaypoint(Vector3 dest) {
		Vector3 direction = dest - this.transform.position;
		float distance = direction.magnitude;
		if(distance < distanceEpsilonCamera) {
			cameraReachedCurrentWaypoint = true;
		}
		else {
			if(linearCameraVelocity)
				direction.Normalize();
			direction.y = 0;
			direction.z = 0;
			this.transform.position += direction * Time.deltaTime * cameraMoveSpeed;
		}
	}
	
	
	void MovePlayerToWaypoint(Vector3 dest) {
		Vector3 direction = dest - player.transform.position;
		float distance = direction.magnitude;
		if(distance < distanceEpsilonPlayer) {
			reachedCurrentWaypoint = true;
		}
		else {
			if(linearPlayerVelocity)
				direction.Normalize();
			player.transform.position += direction * Time.deltaTime * playerMoveSpeed;
		}
	}
	
	void LightUnlockedPaths() {
		//Up to currLevel - 1
		for(int i = 0; i < pathways.Length; i++) {
			if(i <= currLevel - 1) //unlocked paths
			{
				//pathways[i].renderer.material.color =  new Color(1.0f, 0.6f, 0.08f);
				pathways[i].renderer.material.color = new Color(pathways[i].renderer.material.color.r, pathways[i].renderer.material.color.g, pathways[i].renderer.material.color.b, unlockedAlpha);
			}
			else
			{
				//pathways[i].renderer.material.color = new Color(0.8f, 0.8f, 0.8f);	
				pathways[i].renderer.material.color = new Color(pathways[i].renderer.material.color.r, pathways[i].renderer.material.color.g, pathways[i].renderer.material.color.b, lockedAlpha);
			}
		}
	}

}

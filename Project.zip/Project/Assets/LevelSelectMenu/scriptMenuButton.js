#pragma strict

function OnMouseDown(){
    Application.LoadLevel("sceneMainMenu");
}
using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FarseerPhysics.Collision.Shapes;


public class ScriptConveyor : MonoBehaviour {
	
	public float conveyorSpeed = 10.0f;
	
	private Body body;
	
	
	// Use this for initialization
	void Start () {
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.OnCollision += OnCollisionEvent;	

	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		contact.TangentSpeed = conveyorSpeed;
		return true;
	}

}

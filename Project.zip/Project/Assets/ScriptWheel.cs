using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics;


public class ScriptWheel : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
		GetComponent<FSBodyComponent>().PhysicsBody.IsBullet = true;

	}
	
	// Update is called once per frame
	void Update () {
	
	}
}

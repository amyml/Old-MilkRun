using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class ScriptAntiStuck : MonoBehaviour {
	
	public float maxStuckTime = 0.1f;
	
	
	private Body body;
	private float timer = 0.0f;
	private bool isTimerSet = false;
	
	// Use this for initialization
	void Start () {
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		

	}
	

	
	// Update is called once per frame
	void Update () {
		
		
		float currVelocity = body.LinearVelocity.Length();
		if(currVelocity <= 0.01f)
		{
			if(!isTimerSet)
			{
				setTimer();	
			}
			else
			{
				timer -= Time.deltaTime;
				
				if(timer <= 0.0f)
				{
					GetComponent<scriptCharController>().SetGrounded(true);	
				}
			}
		}
		else
		{
			isTimerSet = false;	
		}
		
	
	}
	
	private void setTimer()
	{
		isTimerSet = true;
		timer = maxStuckTime;
	}
}

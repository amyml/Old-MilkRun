using UnityEngine;
using System.Collections;

using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;

public class ScriptEggCollision : MonoBehaviour {
	
	private bool isDead = false;
	public float damageToPlayer = 30.0f;
	
	public float bounceOnKillForce = 50.0f;
	private bool bounceFlag = false;
	public float bounceCoolDown = 0.5f;
	private float bounceCoolDownTimer = 0.0f;
	
	private bool damagedPlayerFlag = false;
	private float damageDelay = 0.1f;
	private float damageDelayTimer = 9999.0f;
	
	private GameObject player;
	private scriptHealth playerHealth;
	//private ScriptCharCollisions scriptCharCollisions;
	private scriptEggAnimation animationScript;
	
	private Body body;
	
	private Fixture bodyCollider;
	private Fixture headCollider;
	
	private scriptStatTracker scriptStatTracker;	
	private scriptSoundsPlayer scriptSoundsPlayer;
	
	// Use this for initialization
	void Start () 
	{
		player = GameObject.FindGameObjectWithTag("MrMilk");
		playerHealth = player.GetComponent<scriptHealth>();
		//scriptCharCollisions = player.GetComponent<ScriptCharCollisions>();
		animationScript = gameObject.GetComponent<scriptEggAnimation>();
		
		body = GetComponent<FSBodyComponent>().PhysicsBody;
		body.OnCollision += OnCollisionEvent;
		body.UserData = "Enemy";
		
		bodyCollider = body.FixtureList[0];
		headCollider = body.FixtureList[1];	
		headCollider.IsSensor = true;
		
		scriptSoundsPlayer = (scriptSoundsPlayer)(GameObject.Find("Sounds").GetComponent("scriptSoundsPlayer"));
	}
	
	// Update is called once per frame
	void Update () 
	{
		//Trying to avoid killing the egg and hurting the player in the same frame
		TickDamageDelayTimer();
		
		if(damagedPlayerFlag && damageDelayTimer <= 0.0f && !bounceFlag)
		{
			//print ("DO SOME DAMAGE");
			DamagePlayer();	
			damagedPlayerFlag = false;
		}
		else if(damagedPlayerFlag && bounceFlag)
		{
			//print ("Damage Cancelled!!");
			damagedPlayerFlag = false;	
		}
		
		
		if(bounceCoolDownTimer >= 0.0f)
		{
			bounceCoolDownTimer -= Time.deltaTime;	
		}	
		
		
		if(bounceFlag && bounceCoolDownTimer <= 0.0f)
		{
			Body pBody = player.GetComponent<FSBodyComponent>().PhysicsBody;
			pBody.LinearVelocity = new FVector2(pBody.LinearVelocity.X, bounceOnKillForce);
			
			bounceFlag = false;
			bounceCoolDownTimer = bounceCoolDown;
			//print ("bounce!");
		}
		

		
		
		if(gameObject.GetComponent<scriptHealth>().Dead() && !isDead)
		{
			isDead = true;
			Death ();
		}
	}
	
	public bool IsAlive()
	{
		return !gameObject.GetComponent<scriptHealth>().Dead();	
	}
	
	public void Death(){
		StartCoroutine(Die ());
	}
	
	// Function handles the enemy's death
	private IEnumerator Die()
	{
		scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.EGGDEATH);
		//Wait for death animation to play out
		yield return new WaitForSeconds(0.8f);
		
		//Decrease enemy count
		scriptStatTracker = (scriptStatTracker)(GameObject.Find("prefabStatTracker").GetComponent("scriptStatTracker"));
		scriptStatTracker.DecreaseEnemyCount();
		
		//Destory the egg
		Destroy(gameObject);
	}
	
	private bool OnCollisionEvent(Fixture fixtureA, Fixture fixtureB, Contact contact)
	{
		if(!IsAlive() && fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptHealth>() != null)
		{
			return false;	
		}		
		
		if(!IsAlive())  //Do nothing while egg is dying
			return true;
		
			
		if(fixtureA == headCollider && (string) fixtureB.Body.UserData == "Player")
		{
			scriptHealth player = fixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptHealth>();
			
			if(player != null)
			{				
				GetComponent<scriptHealth>().Damage(101.0f);
				bounceFlag = true;
			}
		}
		else if(fixtureA == headCollider && (string) fixtureB.Body.UserData == "Enemy")
		{
			GetComponent<scriptHealth>().Damage(101.0f);
		}
		else if(fixtureA == bodyCollider && (string) fixtureB.Body.UserData == "Player")
		{
			if(!bounceFlag)
			{
				//gameObject.GetComponent<scriptHealth>().Damage(1.0f);		
				SetDamageDelayTimer();
			}
		}

		return true;
	}
	
	private void DamagePlayer()
	{
		// Cue egg animation
			
				
		if(playerHealth.Damage(damageToPlayer))
		{	
			animationScript.AttackAnim();
			scriptSoundsPlayer.PlaySound(scriptSoundsPlayer.PLAYERHURT);
		}
	}
	
	
	private void SetDamageDelayTimer()
	{
		if(!damagedPlayerFlag)
		{
			damagedPlayerFlag = true;
			damageDelayTimer = damageDelay;
		}	
		
	}
	
	private void TickDamageDelayTimer()
	{
		if(damagedPlayerFlag && damageDelayTimer >= 0.0f )
		{
			damageDelayTimer -= Time.deltaTime;	
		//	print (damageDelayTimer);
		}
	}
	
	/*private int GetDirectionToPlayer()
	{
		Vector2 targetVector = player.transform.position - this.transform.position;
		float dir = targetVector.x;
		if(dir < 0) //to the left
			return -1;
		else if(dir > 0) //to the right
			return 1;
		else //directly above
			return 0;
	}*/
	
}

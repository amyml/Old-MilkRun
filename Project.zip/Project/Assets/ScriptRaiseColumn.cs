using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;
using FVector2 = Microsoft.Xna.Framework.FVector2;



public class ScriptRaiseColumn : MonoBehaviour {
	
	
	public GameObject roboChicken;
	scriptHealth roboHealth;
	
	Body body;
	
	
	// Use this for initialization
	void Start () {
		
		body = gameObject.GetComponent<FSBodyComponent>().PhysicsBody;
		
		//roboChicken = GameObject.Find("objectRoboChicken");
		roboHealth = roboChicken.GetComponent<scriptHealth>();
	}
	
	// Update is called once per frame
	void Update () {
	
		if(roboHealth.Dead())
		{
			body.LinearVelocity = new FVector2(0.0f, 0.3f);
		}
	}
}

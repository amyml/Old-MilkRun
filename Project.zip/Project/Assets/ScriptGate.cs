using UnityEngine;
using System.Collections;
using FarseerPhysics.Dynamics.Contacts;
using FarseerPhysics.Dynamics;

public class ScriptGate : MonoBehaviour {
	
	private Body body;
	
	// Use this for initialization
	void Start () {
		body = gameObject.GetComponent<FSBodyComponent>().PhysicsBody;
		
		body.OnCollision += OnCollisionEvent;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	private bool OnCollisionEvent(Fixture FixtureA, Fixture FixtureB, Contact contact)
	{
		if(FixtureB.Body.UserFSBodyComponent.gameObject.GetComponent<scriptHealth>() != null)
		{
			return false;
		}
		else
		{
			return true;	
		}
	}

	
}
